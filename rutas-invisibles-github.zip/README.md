# 🧭 Rutas Invisibles

**Decisiones que construyen tu camino.** Un juego de decisiones para la vida real: 10 situaciones escolares y cotidianas, en español e inglés.

## Cómo se juega
Cada situación tiene tres opciones. Tu puntaje cambia según la decisión:

| Decisión | Puntos |
|---|---|
| Buena | **+5** |
| Aceptable | **+1** |
| Mala | **-5** |

El puntaje final va de **-50 a 50** y determina tu nivel al terminar.

## Características
- Funciona en celular, tablet y computadora (diseño adaptable)
- 3 temas de color y control de volumen
- Sin dependencias, sin servidor, sin instalación
- Atajos de teclado: `1`/`2`/`3` o `A`/`B`/`C` para elegir, `Enter` para continuar

## Estructura
```
index.html      Página principal
css/style.css   Estilos
js/game.js      Lógica y situaciones
assets/         Imágenes
```

## Publicar con GitHub Pages
1. Sube todo el contenido de esta carpeta a un repositorio nuevo.
2. Ve a **Settings → Pages**.
3. En **Build and deployment**, elige **Deploy from a branch**, rama `main` y carpeta `/ (root)`.
4. Guarda. En un minuto el juego estará en `https://TU-USUARIO.github.io/NOMBRE-DEL-REPO/`.

## Jugar en local
Abre `index.html` en tu navegador.
