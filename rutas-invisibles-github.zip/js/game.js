/* ============================================================
   RUTAS INVISIBLES — Lógica del juego
   ------------------------------------------------------------
   JavaScript puro, sin frameworks ni conexión a servidores.
   Estructura:
     1. Datos de situaciones (ES/EN)
     2. Niveles finales (ES/EN)
     3. Textos de interfaz (ES/EN)
     4. Estado y configuración del juego
     5. Referencias al DOM
     6. Sonido (Web Audio API)
     7. Navegación entre pantallas
     8. Aplicar idioma / tema / volumen
     9. Lógica del juego (situaciones, elecciones, puntaje)
    10. Eventos
   ============================================================ */

/* ---------------------------------------------------------
   1. SITUACIONES — Español
--------------------------------------------------------- */
const SITUACIONES_ES = [
  {
    titulo: "La burla en el patio",
    historia: "Durante el recreo ves a un grupo de compañeros burlándose de un estudiante nuevo por su forma de vestir. Él está solo y se ve incómodo.",
    imagen: "data:image/svg+xml;utf8,%3Csvg%20viewBox%3D%220%200%20400%20300%22%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%3E%0A%20%20%3Cdefs%3E%0A%20%20%20%20%3ClinearGradient%20id%3D%22bg1%22%20x1%3D%220%22%20y1%3D%220%22%20x2%3D%221%22%20y2%3D%221%22%3E%0A%20%20%20%20%20%20%3Cstop%20offset%3D%220%25%22%20stop-color%3D%22%2323232f%22/%3E%0A%20%20%20%20%20%20%3Cstop%20offset%3D%22100%25%22%20stop-color%3D%22%23121218%22/%3E%0A%20%20%20%20%3C/linearGradient%3E%0A%20%20%3C/defs%3E%0A%20%20%3Crect%20width%3D%22400%22%20height%3D%22300%22%20rx%3D%2224%22%20fill%3D%22url%28%23bg1%29%22/%3E%0A%20%20%3Crect%20x%3D%220%22%20y%3D%22245%22%20width%3D%22400%22%20height%3D%2255%22%20fill%3D%22%232a2a38%22/%3E%0A%0A%20%20%3Cg%20stroke%3D%22%23161620%22%20stroke-width%3D%223%22%20stroke-linejoin%3D%22round%22%3E%0A%20%20%20%20%3Cpath%20d%3D%22M75%20213%20q20%20-20%2042%200%20v48%20q-21%2010%20-42%200%20z%22%20fill%3D%22%234ECDC4%22/%3E%0A%20%20%20%20%3Ccircle%20cx%3D%2296%22%20cy%3D%22182%22%20r%3D%2226%22%20fill%3D%22%23FFD9B3%22/%3E%0A%20%20%3C/g%3E%0A%20%20%3Cellipse%20cx%3D%2287%22%20cy%3D%22180%22%20rx%3D%226%22%20ry%3D%227%22%20fill%3D%22%23fff%22/%3E%0A%20%20%3Cellipse%20cx%3D%22107%22%20cy%3D%22180%22%20rx%3D%226%22%20ry%3D%227%22%20fill%3D%22%23fff%22/%3E%0A%20%20%3Ccircle%20cx%3D%2288%22%20cy%3D%22182%22%20r%3D%223%22%20fill%3D%22%231a1a1a%22/%3E%0A%20%20%3Ccircle%20cx%3D%22108%22%20cy%3D%22182%22%20r%3D%223%22%20fill%3D%22%231a1a1a%22/%3E%0A%20%20%3Cpath%20d%3D%22M87%20196%20q9%20-8%2018%200%22%20stroke%3D%22%237a4a2a%22%20stroke-width%3D%223%22%20fill%3D%22none%22%20stroke-linecap%3D%22round%22/%3E%0A%0A%20%20%3Cg%20stroke%3D%22%23161620%22%20stroke-width%3D%223%22%20stroke-linejoin%3D%22round%22%3E%0A%20%20%20%20%3Cpath%20d%3D%22M202%20200%20q17%20-16%2036%200%20v42%20q-18%208%20-36%200%20z%22%20fill%3D%22%23EF476F%22/%3E%0A%20%20%20%20%3Ccircle%20cx%3D%22220%22%20cy%3D%22170%22%20r%3D%2221%22%20fill%3D%22%23FFD9B3%22/%3E%0A%20%20%3C/g%3E%0A%20%20%3Cellipse%20cx%3D%22212%22%20cy%3D%22168%22%20rx%3D%225%22%20ry%3D%226%22%20fill%3D%22%23fff%22/%3E%3Ccircle%20cx%3D%22212%22%20cy%3D%22169%22%20r%3D%222.5%22%20fill%3D%22%231a1a1a%22/%3E%0A%20%20%3Cellipse%20cx%3D%22228%22%20cy%3D%22168%22%20rx%3D%225%22%20ry%3D%226%22%20fill%3D%22%23fff%22/%3E%3Ccircle%20cx%3D%22228%22%20cy%3D%22169%22%20r%3D%222.5%22%20fill%3D%22%231a1a1a%22/%3E%0A%20%20%3Cpath%20d%3D%22M212%20180%20q9%206%2018%200%22%20stroke%3D%22%231a1a1a%22%20stroke-width%3D%222.5%22%20fill%3D%22none%22%20stroke-linecap%3D%22round%22/%3E%0A%20%20%3Cpath%20d%3D%22M238%20210%20l32%20-22%22%20stroke%3D%22%23EF476F%22%20stroke-width%3D%226%22%20stroke-linecap%3D%22round%22/%3E%0A%0A%20%20%3Cg%20stroke%3D%22%23161620%22%20stroke-width%3D%223%22%20stroke-linejoin%3D%22round%22%3E%0A%20%20%20%20%3Cpath%20d%3D%22M262%20208%20q17%20-16%2036%200%20v42%20q-18%208%20-36%200%20z%22%20fill%3D%22%23FFD166%22/%3E%0A%20%20%20%20%3Ccircle%20cx%3D%22280%22%20cy%3D%22180%22%20r%3D%2219%22%20fill%3D%22%23e7b88a%22/%3E%0A%20%20%3C/g%3E%0A%20%20%3Cellipse%20cx%3D%22273%22%20cy%3D%22178%22%20rx%3D%225%22%20ry%3D%226%22%20fill%3D%22%23fff%22/%3E%3Ccircle%20cx%3D%22273%22%20cy%3D%22179%22%20r%3D%222.5%22%20fill%3D%22%231a1a1a%22/%3E%0A%20%20%3Cellipse%20cx%3D%22288%22%20cy%3D%22178%22%20rx%3D%225%22%20ry%3D%226%22%20fill%3D%22%23fff%22/%3E%3Ccircle%20cx%3D%22288%22%20cy%3D%22179%22%20r%3D%222.5%22%20fill%3D%22%231a1a1a%22/%3E%0A%20%20%3Cpath%20d%3D%22M272%20210%20l-28%20-18%22%20stroke%3D%22%23FFD166%22%20stroke-width%3D%226%22%20stroke-linecap%3D%22round%22/%3E%0A%0A%20%20%3Cg%20stroke%3D%22%23161620%22%20stroke-width%3D%223%22%20stroke-linejoin%3D%22round%22%3E%0A%20%20%20%20%3Cpath%20d%3D%22M312%20200%20q17%20-16%2036%200%20v42%20q-18%208%20-36%200%20z%22%20fill%3D%22%236C5CE7%22/%3E%0A%20%20%20%20%3Ccircle%20cx%3D%22330%22%20cy%3D%22172%22%20r%3D%2219%22%20fill%3D%22%23FFD9B3%22/%3E%0A%20%20%3C/g%3E%0A%20%20%3Cellipse%20cx%3D%22323%22%20cy%3D%22170%22%20rx%3D%225%22%20ry%3D%226%22%20fill%3D%22%23fff%22/%3E%3Ccircle%20cx%3D%22323%22%20cy%3D%22171%22%20r%3D%222.5%22%20fill%3D%22%231a1a1a%22/%3E%0A%20%20%3Cellipse%20cx%3D%22338%22%20cy%3D%22170%22%20rx%3D%225%22%20ry%3D%226%22%20fill%3D%22%23fff%22/%3E%3Ccircle%20cx%3D%22338%22%20cy%3D%22171%22%20r%3D%222.5%22%20fill%3D%22%231a1a1a%22/%3E%0A%0A%20%20%3Cg%20fill%3D%22%23EF476F%22%20stroke%3D%22%23161620%22%20stroke-width%3D%222%22%3E%0A%20%20%20%20%3Cellipse%20cx%3D%22255%22%20cy%3D%22128%22%20rx%3D%2228%22%20ry%3D%2217%22/%3E%0A%20%20%20%20%3Cpolygon%20points%3D%22238%2C140%20233%2C154%20250%2C143%22/%3E%0A%20%20%3C/g%3E%0A%20%20%3Ctext%20x%3D%22255%22%20y%3D%22134%22%20font-size%3D%2216%22%20text-anchor%3D%22middle%22%20fill%3D%22%23161620%22%20font-family%3D%22Arial%22%20font-weight%3D%22bold%22%3E%21%21%3C/text%3E%0A%3C/svg%3E%0A",
    opciones: [
      { texto: "Acercarte, pedirles que paren y quedarte hablando con el chico nuevo.", categoria: "buena", puntos: 5,
        consecuencia: "Te acercas con calma y les pides que se detengan. El grupo se dispersa y el chico nuevo te agradece el gesto. Con el tiempo se convierte en un buen amigo." },
      { texto: "No te unes a la burla, pero luego le cuentas a un profesor lo que viste.", categoria: "aceptable", puntos: 1,
        consecuencia: "No participas del acoso y avisas después a un docente. La situación se atiende, aunque el chico nuevo se sintió solo en el momento en que ocurrió." },
      { texto: "Seguir tu camino para no meterte en problemas.", categoria: "mala", puntos: -5,
        consecuencia: "Decides no involucrarte. El chico nuevo se siente aún más excluido y las burlas se repiten los días siguientes." },
    ],
  },
  {
    titulo: "La tentación del examen",
    historia: "No alcanzaste a estudiar todo lo necesario. Durante el examen, tu amigo te hace una seña ofreciéndote pasarte las respuestas.",
    imagen: "data:image/svg+xml;utf8,%3Csvg%20viewBox%3D%220%200%20400%20300%22%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%3E%0A%20%20%3Cdefs%3E%0A%20%20%20%20%3ClinearGradient%20id%3D%22bg2%22%20x1%3D%220%22%20y1%3D%220%22%20x2%3D%221%22%20y2%3D%221%22%3E%0A%20%20%20%20%20%20%3Cstop%20offset%3D%220%25%22%20stop-color%3D%22%2323232f%22/%3E%0A%20%20%20%20%20%20%3Cstop%20offset%3D%22100%25%22%20stop-color%3D%22%23121218%22/%3E%0A%20%20%20%20%3C/linearGradient%3E%0A%20%20%3C/defs%3E%0A%20%20%3Crect%20width%3D%22400%22%20height%3D%22300%22%20rx%3D%2224%22%20fill%3D%22url%28%23bg2%29%22/%3E%0A%20%20%3Crect%20x%3D%2260%22%20y%3D%22200%22%20width%3D%22120%22%20height%3D%2214%22%20rx%3D%224%22%20fill%3D%22%233a3a4a%22%20stroke%3D%22%23161620%22%20stroke-width%3D%222%22/%3E%0A%20%20%3Crect%20x%3D%22220%22%20y%3D%22200%22%20width%3D%22120%22%20height%3D%2214%22%20rx%3D%224%22%20fill%3D%22%233a3a4a%22%20stroke%3D%22%23161620%22%20stroke-width%3D%222%22/%3E%0A%20%20%3Crect%20x%3D%22100%22%20y%3D%22214%22%20width%3D%2210%22%20height%3D%2250%22%20fill%3D%22%23262633%22/%3E%0A%20%20%3Crect%20x%3D%22150%22%20y%3D%22214%22%20width%3D%2210%22%20height%3D%2250%22%20fill%3D%22%23262633%22/%3E%0A%20%20%3Crect%20x%3D%22260%22%20y%3D%22214%22%20width%3D%2210%22%20height%3D%2250%22%20fill%3D%22%23262633%22/%3E%0A%20%20%3Crect%20x%3D%22310%22%20y%3D%22214%22%20width%3D%2210%22%20height%3D%2250%22%20fill%3D%22%23262633%22/%3E%0A%0A%20%20%3Crect%20x%3D%2290%22%20y%3D%22175%22%20width%3D%2260%22%20height%3D%2230%22%20rx%3D%223%22%20fill%3D%22%23F4F4F9%22%20stroke%3D%22%23161620%22%20stroke-width%3D%222%22/%3E%0A%20%20%3Crect%20x%3D%22250%22%20y%3D%22175%22%20width%3D%2260%22%20height%3D%2230%22%20rx%3D%223%22%20fill%3D%22%23F4F4F9%22%20stroke%3D%22%23161620%22%20stroke-width%3D%222%22/%3E%0A%20%20%3Cg%20stroke%3D%22%239aa0c9%22%20stroke-width%3D%222%22%3E%0A%20%20%20%20%3Cline%20x1%3D%2298%22%20y1%3D%22184%22%20x2%3D%22140%22%20y2%3D%22184%22/%3E%0A%20%20%20%20%3Cline%20x1%3D%2298%22%20y1%3D%22192%22%20x2%3D%22130%22%20y2%3D%22192%22/%3E%0A%20%20%20%20%3Cline%20x1%3D%22258%22%20y1%3D%22184%22%20x2%3D%22300%22%20y2%3D%22184%22/%3E%0A%20%20%20%20%3Cline%20x1%3D%22258%22%20y1%3D%22192%22%20x2%3D%22290%22%20y2%3D%22192%22/%3E%0A%20%20%3C/g%3E%0A%0A%20%20%3Cg%20stroke%3D%22%23161620%22%20stroke-width%3D%223%22%20stroke-linejoin%3D%22round%22%3E%0A%20%20%20%20%3Cpath%20d%3D%22M96%20172%20q24%20-18%2048%200%20v24%22%20fill%3D%22%234ECDC4%22/%3E%0A%20%20%20%20%3Ccircle%20cx%3D%22120%22%20cy%3D%22148%22%20r%3D%2224%22%20fill%3D%22%23FFD9B3%22/%3E%0A%20%20%3C/g%3E%0A%20%20%3Cellipse%20cx%3D%22111%22%20cy%3D%22146%22%20rx%3D%225.5%22%20ry%3D%226.5%22%20fill%3D%22%23fff%22/%3E%3Ccircle%20cx%3D%22111%22%20cy%3D%22147%22%20r%3D%223%22%20fill%3D%22%231a1a1a%22/%3E%0A%20%20%3Cellipse%20cx%3D%22129%22%20cy%3D%22146%22%20rx%3D%225.5%22%20ry%3D%226.5%22%20fill%3D%22%23fff%22/%3E%3Ccircle%20cx%3D%22129%22%20cy%3D%22147%22%20r%3D%223%22%20fill%3D%22%231a1a1a%22/%3E%0A%20%20%3Cpath%20d%3D%22M111%20160%20q9%205%2018%200%22%20stroke%3D%22%237a4a2a%22%20stroke-width%3D%222.5%22%20fill%3D%22none%22%20stroke-linecap%3D%22round%22/%3E%0A%0A%20%20%3Cg%20stroke%3D%22%23161620%22%20stroke-width%3D%223%22%20stroke-linejoin%3D%22round%22%3E%0A%20%20%20%20%3Cpath%20d%3D%22M256%20172%20q24%20-18%2048%200%20v24%22%20fill%3D%22%23FFD166%22/%3E%0A%20%20%20%20%3Ccircle%20cx%3D%22280%22%20cy%3D%22148%22%20r%3D%2224%22%20fill%3D%22%23e7b88a%22/%3E%0A%20%20%3C/g%3E%0A%20%20%3Cellipse%20cx%3D%22271%22%20cy%3D%22146%22%20rx%3D%225.5%22%20ry%3D%226.5%22%20fill%3D%22%23fff%22/%3E%3Ccircle%20cx%3D%22271%22%20cy%3D%22147%22%20r%3D%223%22%20fill%3D%22%231a1a1a%22/%3E%0A%20%20%3Cellipse%20cx%3D%22289%22%20cy%3D%22146%22%20rx%3D%225.5%22%20ry%3D%226.5%22%20fill%3D%22%23fff%22/%3E%3Ccircle%20cx%3D%22289%22%20cy%3D%22147%22%20r%3D%223%22%20fill%3D%22%231a1a1a%22/%3E%0A%0A%20%20%3Cpath%20d%3D%22M144%20148%20q40%20-12%2082%200%22%20stroke%3D%22%23EF476F%22%20stroke-width%3D%223%22%20stroke-dasharray%3D%226%206%22%20fill%3D%22none%22/%3E%0A%20%20%3Cg%20stroke%3D%22%23161620%22%20stroke-width%3D%222%22%3E%0A%20%20%20%20%3Cellipse%20cx%3D%22200%22%20cy%3D%22115%22%20rx%3D%2232%22%20ry%3D%2219%22%20fill%3D%22%23EF476F%22/%3E%0A%20%20%20%20%3Cpolygon%20points%3D%22188%2C132%20178%2C146%20198%2C134%22%20fill%3D%22%23EF476F%22/%3E%0A%20%20%3C/g%3E%0A%20%20%3Ctext%20x%3D%22200%22%20y%3D%22122%22%20font-size%3D%2218%22%20text-anchor%3D%22middle%22%20fill%3D%22%23161620%22%20font-family%3D%22Arial%22%20font-weight%3D%22bold%22%3E%3F%3C/text%3E%0A%3C/svg%3E%0A",
    opciones: [
      { texto: "Rechazar la propuesta y responder con lo que sí sabes.", categoria: "buena", puntos: 5,
        consecuencia: "Decides ser honesto contigo mismo. Obtienes una nota más baja de la que esperabas, pero sabes exactamente en qué necesitas reforzar." },
      { texto: "Aceptar la ayuda solo en una pregunta que realmente no sabes.", categoria: "aceptable", puntos: 1,
        consecuencia: "Usas la ayuda de forma puntual. Apruebas el examen, aunque te queda la sensación de que no fue del todo justo." },
      { texto: "Copiar todas las respuestas que puedas.", categoria: "mala", puntos: -5,
        consecuencia: "Apruebas el examen, pero el profesor nota las coincidencias exactas con tu amigo. Ambos deben repetir la evaluación." },
    ],
  },
  {
    titulo: "La tarde libre",
    historia: "Tienes un examen importante en dos días y toda una tarde libre por delante. Tu videojuego favorito recibió una actualización nueva.",
    imagen: "data:image/svg+xml;utf8,%3Csvg%20viewBox%3D%220%200%20400%20300%22%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%3E%0A%20%20%3Cdefs%3E%0A%20%20%20%20%3ClinearGradient%20id%3D%22bg3%22%20x1%3D%220%22%20y1%3D%220%22%20x2%3D%221%22%20y2%3D%221%22%3E%0A%20%20%20%20%20%20%3Cstop%20offset%3D%220%25%22%20stop-color%3D%22%2323232f%22/%3E%0A%20%20%20%20%20%20%3Cstop%20offset%3D%22100%25%22%20stop-color%3D%22%23121218%22/%3E%0A%20%20%20%20%3C/linearGradient%3E%0A%20%20%3C/defs%3E%0A%20%20%3Crect%20width%3D%22400%22%20height%3D%22300%22%20rx%3D%2224%22%20fill%3D%22url%28%23bg3%29%22/%3E%0A%20%20%3Cpath%20d%3D%22M200%2020%20v260%22%20stroke%3D%22%233a3a4a%22%20stroke-width%3D%223%22%20stroke-dasharray%3D%228%208%22/%3E%0A%0A%20%20%3Cg%20stroke%3D%22%23161620%22%20stroke-width%3D%222.5%22%3E%0A%20%20%20%20%3Crect%20x%3D%2260%22%20y%3D%22190%22%20width%3D%2290%22%20height%3D%2214%22%20rx%3D%223%22%20fill%3D%22%234ECDC4%22/%3E%0A%20%20%20%20%3Crect%20x%3D%2265%22%20y%3D%22176%22%20width%3D%2280%22%20height%3D%2214%22%20rx%3D%223%22%20fill%3D%22%236C5CE7%22/%3E%0A%20%20%20%20%3Crect%20x%3D%2270%22%20y%3D%22162%22%20width%3D%2270%22%20height%3D%2214%22%20rx%3D%223%22%20fill%3D%22%23FFD166%22/%3E%0A%20%20%20%20%3Crect%20x%3D%2295%22%20y%3D%22120%22%20width%3D%2220%22%20height%3D%2242%22%20fill%3D%22%233a3a4a%22/%3E%0A%20%20%20%20%3Ccircle%20cx%3D%22105%22%20cy%3D%22112%22%20r%3D%2214%22%20fill%3D%22%23FFF3D0%22/%3E%0A%20%20%3C/g%3E%0A%0A%20%20%3Cg%20stroke%3D%22%23161620%22%20stroke-width%3D%223%22%3E%0A%20%20%20%20%3Crect%20x%3D%22270%22%20y%3D%22170%22%20width%3D%2290%22%20height%3D%2240%22%20rx%3D%2218%22%20fill%3D%22%23EF476F%22/%3E%0A%20%20%3C/g%3E%0A%20%20%3Ccircle%20cx%3D%22290%22%20cy%3D%22190%22%20r%3D%226%22%20fill%3D%22%231a1a1a%22/%3E%0A%20%20%3Ccircle%20cx%3D%22340%22%20cy%3D%22180%22%20r%3D%226%22%20fill%3D%22%231a1a1a%22/%3E%0A%20%20%3Ccircle%20cx%3D%22350%22%20cy%3D%22190%22%20r%3D%226%22%20fill%3D%22%231a1a1a%22/%3E%0A%20%20%3Ccircle%20cx%3D%22340%22%20cy%3D%22200%22%20r%3D%226%22%20fill%3D%22%231a1a1a%22/%3E%0A%0A%20%20%3Cg%20stroke%3D%22%23161620%22%20stroke-width%3D%223%22%20stroke-linejoin%3D%22round%22%3E%0A%20%20%20%20%3Cpath%20d%3D%22M178%20172%20q22%20-18%2044%200%20v42%20q-22%208%20-44%200%20z%22%20fill%3D%22%23F4F4F9%22/%3E%0A%20%20%20%20%3Ccircle%20cx%3D%22200%22%20cy%3D%22146%22%20r%3D%2224%22%20fill%3D%22%23FFD9B3%22/%3E%0A%20%20%3C/g%3E%0A%20%20%3Cellipse%20cx%3D%22191%22%20cy%3D%22144%22%20rx%3D%225.5%22%20ry%3D%226.5%22%20fill%3D%22%23fff%22/%3E%3Ccircle%20cx%3D%22191%22%20cy%3D%22145%22%20r%3D%223%22%20fill%3D%22%231a1a1a%22/%3E%0A%20%20%3Cellipse%20cx%3D%22209%22%20cy%3D%22144%22%20rx%3D%225.5%22%20ry%3D%226.5%22%20fill%3D%22%23fff%22/%3E%3Ccircle%20cx%3D%22209%22%20cy%3D%22145%22%20r%3D%223%22%20fill%3D%22%231a1a1a%22/%3E%0A%20%20%3Cpath%20d%3D%22M191%20158%20q9%20-4%2018%200%22%20stroke%3D%22%237a4a2a%22%20stroke-width%3D%222.5%22%20fill%3D%22none%22%20stroke-linecap%3D%22round%22/%3E%0A%20%20%3Cpath%20d%3D%22M170%20250%20q30%20-20%2060%200%22%20stroke%3D%22%239aa0c9%22%20stroke-width%3D%223%22%20fill%3D%22none%22%20stroke-dasharray%3D%224%204%22/%3E%0A%3C/svg%3E%0A",
    opciones: [
      { texto: "Organizar tu tiempo: estudiar primero y jugar después, sin culpa.", categoria: "buena", puntos: 5,
        consecuencia: "Divides tu tarde en bloques. Repasas los temas más importantes y luego disfrutas tu juego tranquilo, sabiendo que ya hiciste lo necesario." },
      { texto: "Jugar un rato primero y dejar el estudio para la noche.", categoria: "aceptable", puntos: 1,
        consecuencia: "Terminas estudiando cansado y con menos concentración de la que hubieras tenido más temprano." },
      { texto: "Jugar toda la tarde y dejar todo el estudio para último momento.", categoria: "mala", puntos: -5,
        consecuencia: "Llegas al examen sin haber repasado casi nada. Te cuesta mucho responder y el resultado no refleja lo que realmente sabes." },
    ],
  },
  {
    titulo: "El hallazgo en la calle",
    historia: "Caminando de regreso a casa, encuentras en la vereda una billetera con dinero y documentos de identidad.",
    imagen: "data:image/svg+xml;utf8,%3Csvg%20viewBox%3D%220%200%20400%20300%22%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%3E%0A%20%20%3Cdefs%3E%0A%20%20%20%20%3ClinearGradient%20id%3D%22bg4%22%20x1%3D%220%22%20y1%3D%220%22%20x2%3D%221%22%20y2%3D%221%22%3E%0A%20%20%20%20%20%20%3Cstop%20offset%3D%220%25%22%20stop-color%3D%22%2323232f%22/%3E%0A%20%20%20%20%20%20%3Cstop%20offset%3D%22100%25%22%20stop-color%3D%22%23121218%22/%3E%0A%20%20%20%20%3C/linearGradient%3E%0A%20%20%3C/defs%3E%0A%20%20%3Crect%20width%3D%22400%22%20height%3D%22300%22%20rx%3D%2224%22%20fill%3D%22url%28%23bg4%29%22/%3E%0A%20%20%3Crect%20x%3D%220%22%20y%3D%22220%22%20width%3D%22400%22%20height%3D%2280%22%20fill%3D%22%23262633%22/%3E%0A%20%20%3Cline%20x1%3D%220%22%20y1%3D%22240%22%20x2%3D%22400%22%20y2%3D%22240%22%20stroke%3D%22%233a3a4a%22%20stroke-width%3D%223%22%20stroke-dasharray%3D%2210%2010%22/%3E%0A%0A%20%20%3Cg%20stroke%3D%22%23161620%22%20stroke-width%3D%223%22%3E%0A%20%20%20%20%3Crect%20x%3D%22160%22%20y%3D%22185%22%20width%3D%2290%22%20height%3D%2260%22%20rx%3D%228%22%20fill%3D%22%236C5CE7%22/%3E%0A%20%20%20%20%3Crect%20x%3D%22160%22%20y%3D%22185%22%20width%3D%2245%22%20height%3D%2260%22%20rx%3D%228%22%20fill%3D%22%235847c7%22/%3E%0A%20%20%3C/g%3E%0A%20%20%3Cline%20x1%3D%22205%22%20y1%3D%22185%22%20x2%3D%22205%22%20y2%3D%22245%22%20stroke%3D%22%231a1a1a%22%20stroke-width%3D%222%22/%3E%0A%0A%20%20%3Ccircle%20cx%3D%22130%22%20cy%3D%22235%22%20r%3D%2212%22%20fill%3D%22%23FFD166%22%20stroke%3D%22%23161620%22%20stroke-width%3D%222%22/%3E%0A%20%20%3Ccircle%20cx%3D%22110%22%20cy%3D%22250%22%20r%3D%2210%22%20fill%3D%22%23FFD166%22%20stroke%3D%22%23161620%22%20stroke-width%3D%222%22/%3E%0A%20%20%3Crect%20x%3D%22255%22%20y%3D%22215%22%20width%3D%2240%22%20height%3D%2220%22%20rx%3D%223%22%20fill%3D%22%234ECDC4%22%20stroke%3D%22%23161620%22%20stroke-width%3D%222%22/%3E%0A%20%20%3Crect%20x%3D%22270%22%20y%3D%22230%22%20width%3D%2240%22%20height%3D%2220%22%20rx%3D%223%22%20fill%3D%22%234ECDC4%22%20stroke%3D%22%23161620%22%20stroke-width%3D%222%22/%3E%0A%0A%20%20%3Cg%20stroke%3D%22%23161620%22%20stroke-width%3D%223%22%20stroke-linejoin%3D%22round%22%3E%0A%20%20%20%20%3Cpath%20d%3D%22M310%20172%20q22%20-18%2044%200%20v42%20q-22%208%20-44%200%20z%22%20fill%3D%22%23EF476F%22/%3E%0A%20%20%20%20%3Ccircle%20cx%3D%22332%22%20cy%3D%22146%22%20r%3D%2224%22%20fill%3D%22%23FFD9B3%22/%3E%0A%20%20%3C/g%3E%0A%20%20%3Cellipse%20cx%3D%22323%22%20cy%3D%22144%22%20rx%3D%225.5%22%20ry%3D%226.5%22%20fill%3D%22%23fff%22/%3E%3Ccircle%20cx%3D%22323%22%20cy%3D%22145%22%20r%3D%223%22%20fill%3D%22%231a1a1a%22/%3E%0A%20%20%3Cellipse%20cx%3D%22341%22%20cy%3D%22144%22%20rx%3D%225.5%22%20ry%3D%226.5%22%20fill%3D%22%23fff%22/%3E%3Ccircle%20cx%3D%22341%22%20cy%3D%22145%22%20r%3D%223%22%20fill%3D%22%231a1a1a%22/%3E%0A%20%20%3Cellipse%20cx%3D%22332%22%20cy%3D%22159%22%20rx%3D%225%22%20ry%3D%224%22%20fill%3D%22%231a1a1a%22/%3E%0A%3C/svg%3E%0A",
    opciones: [
      { texto: "Buscar un contacto en los documentos y devolverla directamente.", categoria: "buena", puntos: 5,
        consecuencia: "Encuentras un número de contacto y avisas al dueño. La persona se muestra muy agradecida por tu honestidad." },
      { texto: "Entregarla a un adulto responsable cercano para que la remita.", categoria: "aceptable", puntos: 1,
        consecuencia: "Entregas la billetera en un lugar de confianza. Es probable que llegue a su dueño, aunque tú no lo confirmas directamente." },
      { texto: "Quedarte con el dinero y desechar el resto.", categoria: "mala", puntos: -5,
        consecuencia: "Te quedas con el dinero, pero la sensación de culpa te acompaña varios días. El dueño pierde documentos importantes." },
    ],
  },
  {
    titulo: "El accidente en el aula",
    historia: "Ves que un compañero rompe accidentalmente un jarrón del salón mientras nadie más lo nota.",
    imagen: "data:image/svg+xml;utf8,%3Csvg%20viewBox%3D%220%200%20400%20300%22%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%3E%0A%20%20%3Cdefs%3E%0A%20%20%20%20%3ClinearGradient%20id%3D%22bg5%22%20x1%3D%220%22%20y1%3D%220%22%20x2%3D%221%22%20y2%3D%221%22%3E%0A%20%20%20%20%20%20%3Cstop%20offset%3D%220%25%22%20stop-color%3D%22%2323232f%22/%3E%0A%20%20%20%20%20%20%3Cstop%20offset%3D%22100%25%22%20stop-color%3D%22%23121218%22/%3E%0A%20%20%20%20%3C/linearGradient%3E%0A%20%20%3C/defs%3E%0A%20%20%3Crect%20width%3D%22400%22%20height%3D%22300%22%20rx%3D%2224%22%20fill%3D%22url%28%23bg5%29%22/%3E%0A%20%20%3Crect%20x%3D%2240%22%20y%3D%2240%22%20width%3D%22320%22%20height%3D%2280%22%20rx%3D%226%22%20fill%3D%22%231f6b5c%22%20stroke%3D%22%23161620%22%20stroke-width%3D%223%22/%3E%0A%20%20%3Cline%20x1%3D%2260%22%20y1%3D%2260%22%20x2%3D%22180%22%20y2%3D%2260%22%20stroke%3D%22%23F4F4F9%22%20stroke-width%3D%223%22%20opacity%3D%220.6%22/%3E%0A%20%20%3Cline%20x1%3D%2260%22%20y1%3D%2280%22%20x2%3D%22150%22%20y2%3D%2280%22%20stroke%3D%22%23F4F4F9%22%20stroke-width%3D%223%22%20opacity%3D%220.6%22/%3E%0A%20%20%3Crect%20x%3D%220%22%20y%3D%22230%22%20width%3D%22400%22%20height%3D%2270%22%20fill%3D%22%23262633%22/%3E%0A%0A%20%20%3Cg%20fill%3D%22%23EF476F%22%20stroke%3D%22%23161620%22%20stroke-width%3D%222%22%3E%0A%20%20%20%20%3Cpolygon%20points%3D%22160%2C230%20190%2C230%20180%2C255%20165%2C250%22/%3E%0A%20%20%20%20%3Cpolygon%20points%3D%22195%2C232%20220%2C235%20210%2C258%20198%2C255%22/%3E%0A%20%20%20%20%3Ccircle%20cx%3D%22150%22%20cy%3D%22248%22%20r%3D%226%22/%3E%0A%20%20%20%20%3Ccircle%20cx%3D%22230%22%20cy%3D%22250%22%20r%3D%228%22/%3E%0A%20%20%3C/g%3E%0A%0A%20%20%3Cg%20stroke%3D%22%23161620%22%20stroke-width%3D%223%22%20stroke-linejoin%3D%22round%22%3E%0A%20%20%20%20%3Cpath%20d%3D%22M270%20197%20q22%20-18%2044%200%20v42%20q-22%208%20-44%200%20z%22%20fill%3D%22%23FFD166%22/%3E%0A%20%20%20%20%3Ccircle%20cx%3D%22292%22%20cy%3D%22171%22%20r%3D%2224%22%20fill%3D%22%23FFD9B3%22/%3E%0A%20%20%3C/g%3E%0A%20%20%3Cellipse%20cx%3D%22283%22%20cy%3D%22168%22%20rx%3D%227%22%20ry%3D%228%22%20fill%3D%22%23fff%22/%3E%3Ccircle%20cx%3D%22283%22%20cy%3D%22169%22%20r%3D%223.5%22%20fill%3D%22%231a1a1a%22/%3E%0A%20%20%3Cellipse%20cx%3D%22301%22%20cy%3D%22168%22%20rx%3D%227%22%20ry%3D%228%22%20fill%3D%22%23fff%22/%3E%3Ccircle%20cx%3D%22301%22%20cy%3D%22169%22%20r%3D%223.5%22%20fill%3D%22%231a1a1a%22/%3E%0A%20%20%3Cellipse%20cx%3D%22292%22%20cy%3D%22184%22%20rx%3D%226%22%20ry%3D%228%22%20fill%3D%22%231a1a1a%22/%3E%0A%3C/svg%3E%0A",
    opciones: [
      { texto: "Animarlo a contarlo juntos al profesor apenas termine la clase.", categoria: "buena", puntos: 5,
        consecuencia: "Ambos hablan con el profesor con honestidad. Él valora que lo hayan contado por su cuenta y no hay mayores consecuencias." },
      { texto: "No decir nada tú, pero sugerirle que lo cuente él solo.", categoria: "aceptable", puntos: 1,
        consecuencia: "Tu compañero decide contarlo más tarde, aunque duda bastante antes de hacerlo." },
      { texto: "Sugerirle que no diga nada y, si preguntan, culpar a otra persona.", categoria: "mala", puntos: -5,
        consecuencia: "La mentira se descubre días después. La confianza del profesor hacia ambos se ve afectada." },
    ],
  },
  {
    titulo: "Un mensaje hiriente",
    historia: "Recibes un mensaje ofensivo de una cuenta desconocida en redes sociales, burlándose de tu aspecto físico.",
    imagen: "data:image/svg+xml;utf8,%3Csvg%20viewBox%3D%220%200%20400%20300%22%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%3E%0A%20%20%3Cdefs%3E%0A%20%20%20%20%3ClinearGradient%20id%3D%22bg6%22%20x1%3D%220%22%20y1%3D%220%22%20x2%3D%221%22%20y2%3D%221%22%3E%0A%20%20%20%20%20%20%3Cstop%20offset%3D%220%25%22%20stop-color%3D%22%2323232f%22/%3E%0A%20%20%20%20%20%20%3Cstop%20offset%3D%22100%25%22%20stop-color%3D%22%23121218%22/%3E%0A%20%20%20%20%3C/linearGradient%3E%0A%20%20%3C/defs%3E%0A%20%20%3Crect%20width%3D%22400%22%20height%3D%22300%22%20rx%3D%2224%22%20fill%3D%22url%28%23bg6%29%22/%3E%0A%20%20%3Crect%20x%3D%22160%22%20y%3D%2290%22%20width%3D%2290%22%20height%3D%22150%22%20rx%3D%2216%22%20fill%3D%22%230f0f14%22%20stroke%3D%22%23161620%22%20stroke-width%3D%223%22/%3E%0A%20%20%3Crect%20x%3D%22170%22%20y%3D%22105%22%20width%3D%2270%22%20height%3D%22120%22%20rx%3D%224%22%20fill%3D%22%23F4F4F9%22/%3E%0A%20%20%3Crect%20x%3D%22178%22%20y%3D%22115%22%20width%3D%2254%22%20height%3D%2224%22%20rx%3D%2210%22%20fill%3D%22%23EF476F%22%20stroke%3D%22%23161620%22%20stroke-width%3D%222%22/%3E%0A%20%20%3Ctext%20x%3D%22205%22%20y%3D%22131%22%20font-size%3D%2212%22%20text-anchor%3D%22middle%22%20fill%3D%22%23F4F4F9%22%20font-family%3D%22Arial%22%3E%3A%28%3C/text%3E%0A%20%20%3Crect%20x%3D%22178%22%20y%3D%22145%22%20width%3D%2240%22%20height%3D%2216%22%20rx%3D%228%22%20fill%3D%22%236C5CE7%22%20stroke%3D%22%23161620%22%20stroke-width%3D%222%22/%3E%0A%20%20%3Ccircle%20cx%3D%22205%22%20cy%3D%22185%22%20r%3D%2218%22%20fill%3D%22%23FFD166%22%20stroke%3D%22%23161620%22%20stroke-width%3D%222%22/%3E%0A%20%20%3Ctext%20x%3D%22205%22%20y%3D%22192%22%20font-size%3D%2220%22%20text-anchor%3D%22middle%22%20fill%3D%22%231a1a1a%22%20font-family%3D%22Arial%22%20font-weight%3D%22bold%22%3E%21%3C/text%3E%0A%0A%20%20%3Cg%20stroke%3D%22%23161620%22%20stroke-width%3D%223%22%20stroke-linejoin%3D%22round%22%3E%0A%20%20%20%20%3Cpath%20d%3D%22M65%20222%20q22%20-18%2044%200%20v42%20q-22%208%20-44%200%20z%22%20fill%3D%22%234ECDC4%22/%3E%0A%20%20%20%20%3Ccircle%20cx%3D%2287%22%20cy%3D%22196%22%20r%3D%2224%22%20fill%3D%22%23FFD9B3%22/%3E%0A%20%20%3C/g%3E%0A%20%20%3Cpath%20d%3D%22M78%20191%20q9%205%2018%200%22%20stroke%3D%22%231a1a1a%22%20stroke-width%3D%222.5%22%20fill%3D%22none%22%20stroke-linecap%3D%22round%22/%3E%0A%20%20%3Cpath%20d%3D%22M96%20191%20q9%205%2018%200%22%20stroke%3D%22%231a1a1a%22%20stroke-width%3D%222.5%22%20fill%3D%22none%22%20stroke-linecap%3D%22round%22/%3E%0A%20%20%3Cpath%20d%3D%22M78%20209%20q9%20-6%2018%200%22%20stroke%3D%22%237a4a2a%22%20stroke-width%3D%223%22%20fill%3D%22none%22%20stroke-linecap%3D%22round%22/%3E%0A%3C/svg%3E%0A",
    opciones: [
      { texto: "Bloquear a la persona, guardar evidencia y contarle a un adulto de confianza.", categoria: "buena", puntos: 5,
        consecuencia: "Actúas con calma y de forma segura. Guardas las pruebas, bloqueas la cuenta y recibes apoyo para resolver la situación." },
      { texto: "Responder pidiendo que se detenga, sin insultar de vuelta.", categoria: "aceptable", puntos: 1,
        consecuencia: "Los mensajes se detienen por un tiempo, pero la persona vuelve a molestarte semanas después desde otra cuenta." },
      { texto: "Responder con más insultos.", categoria: "mala", puntos: -5,
        consecuencia: "La discusión escala rápidamente y terminas sintiéndote peor que al principio." },
    ],
  },
  {
    titulo: "La propuesta de tus amigos",
    historia: "Tus amigos planean escaparse de la última clase para ir a un centro comercial y te invitan a acompañarlos.",
    imagen: "data:image/svg+xml;utf8,%3Csvg%20viewBox%3D%220%200%20400%20300%22%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%3E%0A%20%20%3Cdefs%3E%0A%20%20%20%20%3ClinearGradient%20id%3D%22bg7%22%20x1%3D%220%22%20y1%3D%220%22%20x2%3D%221%22%20y2%3D%221%22%3E%0A%20%20%20%20%20%20%3Cstop%20offset%3D%220%25%22%20stop-color%3D%22%2323232f%22/%3E%0A%20%20%20%20%20%20%3Cstop%20offset%3D%22100%25%22%20stop-color%3D%22%23121218%22/%3E%0A%20%20%20%20%3C/linearGradient%3E%0A%20%20%3C/defs%3E%0A%20%20%3Crect%20width%3D%22400%22%20height%3D%22300%22%20rx%3D%2224%22%20fill%3D%22url%28%23bg7%29%22/%3E%0A%20%20%3Crect%20x%3D%2240%22%20y%3D%2260%22%20width%3D%22140%22%20height%3D%22110%22%20fill%3D%22%233a3a4a%22%20stroke%3D%22%23161620%22%20stroke-width%3D%223%22/%3E%0A%20%20%3Cpolygon%20points%3D%2240%2C60%20110%2C20%20180%2C60%22%20fill%3D%22%23262633%22%20stroke%3D%22%23161620%22%20stroke-width%3D%223%22/%3E%0A%20%20%3Crect%20x%3D%2270%22%20y%3D%2290%22%20width%3D%2224%22%20height%3D%2224%22%20fill%3D%22%23FFD166%22/%3E%0A%20%20%3Crect%20x%3D%22126%22%20y%3D%2290%22%20width%3D%2224%22%20height%3D%2224%22%20fill%3D%22%23FFD166%22/%3E%0A%20%20%3Crect%20x%3D%2298%22%20y%3D%22130%22%20width%3D%2224%22%20height%3D%2240%22%20fill%3D%22%23121218%22/%3E%0A%20%20%3Crect%20x%3D%220%22%20y%3D%22200%22%20width%3D%22400%22%20height%3D%228%22%20fill%3D%22%23262633%22/%3E%0A%0A%20%20%3Cg%20stroke%3D%22%23161620%22%20stroke-width%3D%223%22%20stroke-linejoin%3D%22round%22%3E%0A%20%20%20%20%3Cpath%20d%3D%22M223%20200%20q17%20-16%2034%200%20v40%20q-17%208%20-34%200%20z%22%20fill%3D%22%23EF476F%22/%3E%0A%20%20%20%20%3Ccircle%20cx%3D%22240%22%20cy%3D%22176%22%20r%3D%2220%22%20fill%3D%22%23FFD9B3%22/%3E%0A%20%20%3C/g%3E%0A%20%20%3Cellipse%20cx%3D%22233%22%20cy%3D%22174%22%20rx%3D%225%22%20ry%3D%226%22%20fill%3D%22%23fff%22/%3E%3Ccircle%20cx%3D%22233%22%20cy%3D%22175%22%20r%3D%222.5%22%20fill%3D%22%231a1a1a%22/%3E%0A%20%20%3Cellipse%20cx%3D%22248%22%20cy%3D%22174%22%20rx%3D%225%22%20ry%3D%226%22%20fill%3D%22%23fff%22/%3E%3Ccircle%20cx%3D%22248%22%20cy%3D%22175%22%20r%3D%222.5%22%20fill%3D%22%231a1a1a%22/%3E%0A%0A%20%20%3Cg%20stroke%3D%22%23161620%22%20stroke-width%3D%223%22%20stroke-linejoin%3D%22round%22%3E%0A%20%20%20%20%3Cpath%20d%3D%22M263%20205%20q17%20-16%2034%200%20v40%20q-17%208%20-34%200%20z%22%20fill%3D%22%23FFD166%22/%3E%0A%20%20%20%20%3Ccircle%20cx%3D%22280%22%20cy%3D%22181%22%20r%3D%2220%22%20fill%3D%22%23e7b88a%22/%3E%0A%20%20%3C/g%3E%0A%20%20%3Cellipse%20cx%3D%22273%22%20cy%3D%22179%22%20rx%3D%225%22%20ry%3D%226%22%20fill%3D%22%23fff%22/%3E%3Ccircle%20cx%3D%22273%22%20cy%3D%22180%22%20r%3D%222.5%22%20fill%3D%22%231a1a1a%22/%3E%0A%20%20%3Cellipse%20cx%3D%22288%22%20cy%3D%22179%22%20rx%3D%225%22%20ry%3D%226%22%20fill%3D%22%23fff%22/%3E%3Ccircle%20cx%3D%22288%22%20cy%3D%22180%22%20r%3D%222.5%22%20fill%3D%22%231a1a1a%22/%3E%0A%0A%20%20%3Cg%20stroke%3D%22%23161620%22%20stroke-width%3D%223%22%20stroke-linejoin%3D%22round%22%3E%0A%20%20%20%20%3Cpath%20d%3D%22M303%20200%20q17%20-16%2034%200%20v40%20q-17%208%20-34%200%20z%22%20fill%3D%22%236C5CE7%22/%3E%0A%20%20%20%20%3Ccircle%20cx%3D%22320%22%20cy%3D%22176%22%20r%3D%2220%22%20fill%3D%22%23FFD9B3%22/%3E%0A%20%20%3C/g%3E%0A%20%20%3Cellipse%20cx%3D%22313%22%20cy%3D%22174%22%20rx%3D%225%22%20ry%3D%226%22%20fill%3D%22%23fff%22/%3E%3Ccircle%20cx%3D%22313%22%20cy%3D%22175%22%20r%3D%222.5%22%20fill%3D%22%231a1a1a%22/%3E%0A%20%20%3Cellipse%20cx%3D%22328%22%20cy%3D%22174%22%20rx%3D%225%22%20ry%3D%226%22%20fill%3D%22%23fff%22/%3E%3Ccircle%20cx%3D%22328%22%20cy%3D%22175%22%20r%3D%222.5%22%20fill%3D%22%231a1a1a%22/%3E%0A%0A%20%20%3Cpath%20d%3D%22M300%20240%20l50%200%20l-12%20-10%20M350%20240%20l-12%2010%22%20stroke%3D%22%234ECDC4%22%20stroke-width%3D%224%22%20fill%3D%22none%22%20stroke-linecap%3D%22round%22%20stroke-linejoin%3D%22round%22/%3E%0A%3C/svg%3E%0A",
    opciones: [
      { texto: "Decir que no y quedarte en clase.", categoria: "buena", puntos: 5,
        consecuencia: "Te quedas en clase, no te pierdes contenido importante y evitas una posible sanción." },
      { texto: "Ir un momento corto y regresar antes de que noten tu ausencia.", categoria: "aceptable", puntos: 1,
        consecuencia: "Logras volver a tiempo, pero pasas todo el rato con la preocupación de ser descubierto." },
      { texto: "Irte toda la tarde con ellos.", categoria: "mala", puntos: -5,
        consecuencia: "Faltas a clase, citan a tus padres por la inasistencia y pierdes contenido importante." },
    ],
  },
  {
    titulo: "El dinero de la semana",
    historia: "Tus padres te dan una cantidad de dinero para cubrir tu merienda durante toda la semana escolar.",
    imagen: "data:image/svg+xml;utf8,%3Csvg%20viewBox%3D%220%200%20400%20300%22%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%3E%0A%20%20%3Cdefs%3E%0A%20%20%20%20%3ClinearGradient%20id%3D%22bg8%22%20x1%3D%220%22%20y1%3D%220%22%20x2%3D%221%22%20y2%3D%221%22%3E%0A%20%20%20%20%20%20%3Cstop%20offset%3D%220%25%22%20stop-color%3D%22%2323232f%22/%3E%0A%20%20%20%20%20%20%3Cstop%20offset%3D%22100%25%22%20stop-color%3D%22%23121218%22/%3E%0A%20%20%20%20%3C/linearGradient%3E%0A%20%20%3C/defs%3E%0A%20%20%3Crect%20width%3D%22400%22%20height%3D%22300%22%20rx%3D%2224%22%20fill%3D%22url%28%23bg8%29%22/%3E%0A%0A%20%20%3Cellipse%20cx%3D%22140%22%20cy%3D%22200%22%20rx%3D%2255%22%20ry%3D%2240%22%20fill%3D%22%23FFD166%22%20stroke%3D%22%23161620%22%20stroke-width%3D%223%22/%3E%0A%20%20%3Ccircle%20cx%3D%22185%22%20cy%3D%22185%22%20r%3D%228%22%20fill%3D%22%23FFD166%22%20stroke%3D%22%23161620%22%20stroke-width%3D%222%22/%3E%0A%20%20%3Crect%20x%3D%22130%22%20y%3D%22165%22%20width%3D%2220%22%20height%3D%228%22%20rx%3D%224%22%20fill%3D%22%231a1a1a%22/%3E%0A%20%20%3Ccircle%20cx%3D%22120%22%20cy%3D%22205%22%20r%3D%224%22%20fill%3D%22%231a1a1a%22/%3E%0A%20%20%3Cellipse%20cx%3D%22155%22%20cy%3D%22192%22%20rx%3D%224%22%20ry%3D%225%22%20fill%3D%22%231a1a1a%22/%3E%0A%0A%20%20%3Ccircle%20cx%3D%22130%22%20cy%3D%22130%22%20r%3D%2210%22%20fill%3D%22%234ECDC4%22%20stroke%3D%22%23161620%22%20stroke-width%3D%222%22/%3E%0A%20%20%3Ccircle%20cx%3D%22155%22%20cy%3D%22110%22%20r%3D%2210%22%20fill%3D%22%234ECDC4%22%20stroke%3D%22%23161620%22%20stroke-width%3D%222%22/%3E%0A%20%20%3Ccircle%20cx%3D%22115%22%20cy%3D%22105%22%20r%3D%228%22%20fill%3D%22%234ECDC4%22%20stroke%3D%22%23161620%22%20stroke-width%3D%222%22/%3E%0A%0A%20%20%3Cpath%20d%3D%22M270%20160%20h60%20l-8%2070%20h-44%20z%22%20fill%3D%22%23EF476F%22%20stroke%3D%22%23161620%22%20stroke-width%3D%223%22/%3E%0A%20%20%3Crect%20x%3D%22285%22%20y%3D%22145%22%20width%3D%2230%22%20height%3D%2220%22%20rx%3D%224%22%20fill%3D%22%23EF476F%22%20stroke%3D%22%23161620%22%20stroke-width%3D%222%22/%3E%0A%20%20%3Ccircle%20cx%3D%22300%22%20cy%3D%22190%22%20r%3D%2210%22%20fill%3D%22%23F4F4F9%22%20opacity%3D%220.5%22/%3E%0A%3C/svg%3E%0A",
    opciones: [
      { texto: "Organizar un presupuesto diario antes de gastar nada.", categoria: "buena", puntos: 5,
        consecuencia: "Divides el dinero de forma equitativa entre los días. Te alcanza perfectamente y hasta te sobra un poco." },
      { texto: "Gastar un poco más los primeros días y ajustar después.", categoria: "aceptable", puntos: 1,
        consecuencia: "Disfrutas más al inicio de la semana, pero los últimos días debes reducir tu merienda." },
      { texto: "Gastarlo casi todo el primer día en golosinas.", categoria: "mala", puntos: -5,
        consecuencia: "Te quedas sin dinero para el resto de la semana y terminas pidiendo prestado." },
    ],
  },
  {
    titulo: "Un pedido inesperado",
    historia: "Ya tenías planes con tus amigos para esta tarde, pero un familiar mayor te pide ayuda con algo importante justo en ese momento.",
    imagen: "data:image/svg+xml;utf8,%3Csvg%20viewBox%3D%220%200%20400%20300%22%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%3E%0A%20%20%3Cdefs%3E%0A%20%20%20%20%3ClinearGradient%20id%3D%22bg9%22%20x1%3D%220%22%20y1%3D%220%22%20x2%3D%221%22%20y2%3D%221%22%3E%0A%20%20%20%20%20%20%3Cstop%20offset%3D%220%25%22%20stop-color%3D%22%2323232f%22/%3E%0A%20%20%20%20%20%20%3Cstop%20offset%3D%22100%25%22%20stop-color%3D%22%23121218%22/%3E%0A%20%20%20%20%3C/linearGradient%3E%0A%20%20%3C/defs%3E%0A%20%20%3Crect%20width%3D%22400%22%20height%3D%22300%22%20rx%3D%2224%22%20fill%3D%22url%28%23bg9%29%22/%3E%0A%20%20%3Crect%20x%3D%220%22%20y%3D%22240%22%20width%3D%22400%22%20height%3D%2260%22%20fill%3D%22%23262633%22/%3E%0A%0A%20%20%3Cg%20stroke%3D%22%23161620%22%20stroke-width%3D%223%22%20stroke-linejoin%3D%22round%22%3E%0A%20%20%20%20%3Cpath%20d%3D%22M108%20202%20q22%20-18%2044%200%20v42%20q-22%208%20-44%200%20z%22%20fill%3D%22%236C5CE7%22/%3E%0A%20%20%20%20%3Ccircle%20cx%3D%22130%22%20cy%3D%22176%22%20r%3D%2224%22%20fill%3D%22%23e7b88a%22/%3E%0A%20%20%3C/g%3E%0A%20%20%3Cellipse%20cx%3D%22121%22%20cy%3D%22174%22%20rx%3D%225%22%20ry%3D%226%22%20fill%3D%22%23fff%22/%3E%3Ccircle%20cx%3D%22121%22%20cy%3D%22175%22%20r%3D%222.5%22%20fill%3D%22%231a1a1a%22/%3E%0A%20%20%3Cellipse%20cx%3D%22139%22%20cy%3D%22174%22%20rx%3D%225%22%20ry%3D%226%22%20fill%3D%22%23fff%22/%3E%3Ccircle%20cx%3D%22139%22%20cy%3D%22175%22%20r%3D%222.5%22%20fill%3D%22%231a1a1a%22/%3E%0A%20%20%3Cpath%20d%3D%22M121%20188%20q9%204%2018%200%22%20stroke%3D%22%235c3a1e%22%20stroke-width%3D%222.5%22%20fill%3D%22none%22%20stroke-linecap%3D%22round%22/%3E%0A%20%20%3Crect%20x%3D%2295%22%20y%3D%22235%22%20width%3D%2210%22%20height%3D%2230%22%20fill%3D%22%235a3a1e%22%20stroke%3D%22%23161620%22%20stroke-width%3D%222%22/%3E%0A%20%20%3Cpath%20d%3D%22M150%20215%20q20%205%2030%20-5%22%20stroke%3D%22%23e7b88a%22%20stroke-width%3D%226%22%20fill%3D%22none%22%20stroke-linecap%3D%22round%22/%3E%0A%0A%20%20%3Cg%20stroke%3D%22%23161620%22%20stroke-width%3D%223%22%20stroke-linejoin%3D%22round%22%3E%0A%20%20%20%20%3Cpath%20d%3D%22M268%20192%20q22%20-18%2044%200%20v42%20q-22%208%20-44%200%20z%22%20fill%3D%22%234ECDC4%22/%3E%0A%20%20%20%20%3Ccircle%20cx%3D%22290%22%20cy%3D%22166%22%20r%3D%2224%22%20fill%3D%22%23FFD9B3%22/%3E%0A%20%20%3C/g%3E%0A%20%20%3Cellipse%20cx%3D%22281%22%20cy%3D%22164%22%20rx%3D%225%22%20ry%3D%226%22%20fill%3D%22%23fff%22/%3E%3Ccircle%20cx%3D%22281%22%20cy%3D%22165%22%20r%3D%222.5%22%20fill%3D%22%231a1a1a%22/%3E%0A%20%20%3Cellipse%20cx%3D%22299%22%20cy%3D%22164%22%20rx%3D%225%22%20ry%3D%226%22%20fill%3D%22%23fff%22/%3E%3Ccircle%20cx%3D%22299%22%20cy%3D%22165%22%20r%3D%222.5%22%20fill%3D%22%231a1a1a%22/%3E%0A%20%20%3Crect%20x%3D%22305%22%20y%3D%22195%22%20width%3D%2218%22%20height%3D%2224%22%20rx%3D%224%22%20fill%3D%22%23EF476F%22%20stroke%3D%22%23161620%22%20stroke-width%3D%222%22/%3E%0A%0A%20%20%3Ccircle%20cx%3D%22330%22%20cy%3D%22100%22%20r%3D%2226%22%20fill%3D%22%23FFD166%22%20stroke%3D%22%23161620%22%20stroke-width%3D%223%22/%3E%0A%20%20%3Ccircle%20cx%3D%22330%22%20cy%3D%22100%22%20r%3D%2221%22%20fill%3D%22%231a1a1a%22/%3E%0A%20%20%3Cline%20x1%3D%22330%22%20y1%3D%22100%22%20x2%3D%22330%22%20y2%3D%2286%22%20stroke%3D%22%23FFD166%22%20stroke-width%3D%223%22%20stroke-linecap%3D%22round%22/%3E%0A%20%20%3Cline%20x1%3D%22330%22%20y1%3D%22100%22%20x2%3D%22340%22%20y2%3D%22100%22%20stroke%3D%22%23FFD166%22%20stroke-width%3D%223%22%20stroke-linecap%3D%22round%22/%3E%0A%3C/svg%3E%0A",
    opciones: [
      { texto: "Cambiar tus planes y ayudar a tu familiar.", categoria: "buena", puntos: 5,
        consecuencia: "Ayudas a tu familiar, quien te lo agradece de corazón. Después reprogramas tus planes sin mayor problema." },
      { texto: "Ayudar un rato corto y luego irte con tus amigos.", categoria: "aceptable", puntos: 1,
        consecuencia: "Brindas una ayuda parcial y llegas tarde con tus amigos. Ninguna de las dos cosas queda del todo bien resuelta." },
      { texto: "Ignorar el pedido y seguir con tus planes como estaban.", categoria: "mala", puntos: -5,
        consecuencia: "Tu familiar debe resolverlo solo. Cuando te enteras de lo difícil que fue, te sientes mal por no haber estado presente." },
    ],
  },
  {
    titulo: "Basura en el patio escolar",
    historia: "Notas que se ha acumulado basura cerca de los jardines de tu escuela. Muchos estudiantes pasan por ahí y simplemente la ignoran.",
    imagen: "data:image/svg+xml;utf8,%3Csvg%20viewBox%3D%220%200%20400%20300%22%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%3E%0A%20%20%3Cdefs%3E%0A%20%20%20%20%3ClinearGradient%20id%3D%22bg10%22%20x1%3D%220%22%20y1%3D%220%22%20x2%3D%221%22%20y2%3D%221%22%3E%0A%20%20%20%20%20%20%3Cstop%20offset%3D%220%25%22%20stop-color%3D%22%2323232f%22/%3E%0A%20%20%20%20%20%20%3Cstop%20offset%3D%22100%25%22%20stop-color%3D%22%23121218%22/%3E%0A%20%20%20%20%3C/linearGradient%3E%0A%20%20%3C/defs%3E%0A%20%20%3Crect%20width%3D%22400%22%20height%3D%22300%22%20rx%3D%2224%22%20fill%3D%22url%28%23bg10%29%22/%3E%0A%20%20%3Crect%20x%3D%220%22%20y%3D%22240%22%20width%3D%22400%22%20height%3D%2260%22%20fill%3D%22%23262633%22/%3E%0A%0A%20%20%3Crect%20x%3D%2280%22%20y%3D%22190%22%20width%3D%2216%22%20height%3D%2255%22%20fill%3D%22%235a3a1e%22%20stroke%3D%22%23161620%22%20stroke-width%3D%222%22/%3E%0A%20%20%3Ccircle%20cx%3D%2288%22%20cy%3D%22165%22%20r%3D%2242%22%20fill%3D%22%232fae7a%22%20stroke%3D%22%23161620%22%20stroke-width%3D%223%22/%3E%0A%0A%20%20%3Cg%20fill%3D%22%23EF476F%22%20stroke%3D%22%23161620%22%20stroke-width%3D%222%22%3E%0A%20%20%20%20%3Crect%20x%3D%22150%22%20y%3D%22230%22%20width%3D%2218%22%20height%3D%2212%22%20rx%3D%222%22/%3E%0A%20%20%20%20%3Ccircle%20cx%3D%22190%22%20cy%3D%22235%22%20r%3D%228%22/%3E%0A%20%20%20%20%3Cpolygon%20points%3D%22215%2C225%20230%2C225%20225%2C240%20210%2C238%22/%3E%0A%20%20%3C/g%3E%0A%0A%20%20%3Cg%20stroke%3D%22%23161620%22%20stroke-width%3D%223%22%20stroke-linejoin%3D%22round%22%3E%0A%20%20%20%20%3Cpath%20d%3D%22M278%20197%20q22%20-18%2044%200%20v42%20q-22%208%20-44%200%20z%22%20fill%3D%22%234ECDC4%22/%3E%0A%20%20%20%20%3Ccircle%20cx%3D%22300%22%20cy%3D%22171%22%20r%3D%2224%22%20fill%3D%22%23FFD9B3%22/%3E%0A%20%20%3C/g%3E%0A%20%20%3Cellipse%20cx%3D%22291%22%20cy%3D%22169%22%20rx%3D%225.5%22%20ry%3D%226.5%22%20fill%3D%22%23fff%22/%3E%3Ccircle%20cx%3D%22291%22%20cy%3D%22170%22%20r%3D%223%22%20fill%3D%22%231a1a1a%22/%3E%0A%20%20%3Cellipse%20cx%3D%22309%22%20cy%3D%22169%22%20rx%3D%225.5%22%20ry%3D%226.5%22%20fill%3D%22%23fff%22/%3E%3Ccircle%20cx%3D%22309%22%20cy%3D%22170%22%20r%3D%223%22%20fill%3D%22%231a1a1a%22/%3E%0A%20%20%3Cpath%20d%3D%22M291%20183%20q9%205%2018%200%22%20stroke%3D%22%237a4a2a%22%20stroke-width%3D%222.5%22%20fill%3D%22none%22%20stroke-linecap%3D%22round%22/%3E%0A%20%20%3Crect%20x%3D%22320%22%20y%3D%22205%22%20width%3D%2230%22%20height%3D%2235%22%20rx%3D%224%22%20fill%3D%22%23FFD166%22%20stroke%3D%22%23161620%22%20stroke-width%3D%222%22/%3E%0A%20%20%3Cpath%20d%3D%22M325%20205%20l20%200%22%20stroke%3D%22%231a1a1a%22%20stroke-width%3D%223%22/%3E%0A%3C/svg%3E%0A",
    opciones: [
      { texto: "Organizar una jornada de limpieza con compañeros y proponer puntos de reciclaje.", categoria: "buena", puntos: 5,
        consecuencia: "Logras reunir a un grupo de estudiantes. Limpian la zona juntos y la escuela adopta puntos de reciclaje permanentes." },
      { texto: "Recoger la basura que puedas por tu cuenta.", categoria: "aceptable", puntos: 1,
        consecuencia: "Mejoras la zona un poco con tu propio esfuerzo, aunque el problema de fondo persiste." },
      { texto: "Ignorar el problema porque no es tu responsabilidad directa.", categoria: "mala", puntos: -5,
        consecuencia: "La acumulación de basura continúa creciendo y afecta la imagen de toda la escuela." },
    ],
  },
];

/* ---------------------------------------------------------
   1b. SITUACIONES — English
--------------------------------------------------------- */
const SITUACIONES_EN = [
  {
    titulo: "The Schoolyard Teasing",
    historia: "During recess you see a group of classmates mocking a new student for the way he dresses. He is alone and looks uncomfortable.",
    imagen: "data:image/svg+xml;utf8,%3Csvg%20viewBox%3D%220%200%20400%20300%22%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%3E%0A%20%20%3Cdefs%3E%0A%20%20%20%20%3ClinearGradient%20id%3D%22bg1%22%20x1%3D%220%22%20y1%3D%220%22%20x2%3D%221%22%20y2%3D%221%22%3E%0A%20%20%20%20%20%20%3Cstop%20offset%3D%220%25%22%20stop-color%3D%22%2323232f%22/%3E%0A%20%20%20%20%20%20%3Cstop%20offset%3D%22100%25%22%20stop-color%3D%22%23121218%22/%3E%0A%20%20%20%20%3C/linearGradient%3E%0A%20%20%3C/defs%3E%0A%20%20%3Crect%20width%3D%22400%22%20height%3D%22300%22%20rx%3D%2224%22%20fill%3D%22url%28%23bg1%29%22/%3E%0A%20%20%3Crect%20x%3D%220%22%20y%3D%22245%22%20width%3D%22400%22%20height%3D%2255%22%20fill%3D%22%232a2a38%22/%3E%0A%0A%20%20%3Cg%20stroke%3D%22%23161620%22%20stroke-width%3D%223%22%20stroke-linejoin%3D%22round%22%3E%0A%20%20%20%20%3Cpath%20d%3D%22M75%20213%20q20%20-20%2042%200%20v48%20q-21%2010%20-42%200%20z%22%20fill%3D%22%234ECDC4%22/%3E%0A%20%20%20%20%3Ccircle%20cx%3D%2296%22%20cy%3D%22182%22%20r%3D%2226%22%20fill%3D%22%23FFD9B3%22/%3E%0A%20%20%3C/g%3E%0A%20%20%3Cellipse%20cx%3D%2287%22%20cy%3D%22180%22%20rx%3D%226%22%20ry%3D%227%22%20fill%3D%22%23fff%22/%3E%0A%20%20%3Cellipse%20cx%3D%22107%22%20cy%3D%22180%22%20rx%3D%226%22%20ry%3D%227%22%20fill%3D%22%23fff%22/%3E%0A%20%20%3Ccircle%20cx%3D%2288%22%20cy%3D%22182%22%20r%3D%223%22%20fill%3D%22%231a1a1a%22/%3E%0A%20%20%3Ccircle%20cx%3D%22108%22%20cy%3D%22182%22%20r%3D%223%22%20fill%3D%22%231a1a1a%22/%3E%0A%20%20%3Cpath%20d%3D%22M87%20196%20q9%20-8%2018%200%22%20stroke%3D%22%237a4a2a%22%20stroke-width%3D%223%22%20fill%3D%22none%22%20stroke-linecap%3D%22round%22/%3E%0A%0A%20%20%3Cg%20stroke%3D%22%23161620%22%20stroke-width%3D%223%22%20stroke-linejoin%3D%22round%22%3E%0A%20%20%20%20%3Cpath%20d%3D%22M202%20200%20q17%20-16%2036%200%20v42%20q-18%208%20-36%200%20z%22%20fill%3D%22%23EF476F%22/%3E%0A%20%20%20%20%3Ccircle%20cx%3D%22220%22%20cy%3D%22170%22%20r%3D%2221%22%20fill%3D%22%23FFD9B3%22/%3E%0A%20%20%3C/g%3E%0A%20%20%3Cellipse%20cx%3D%22212%22%20cy%3D%22168%22%20rx%3D%225%22%20ry%3D%226%22%20fill%3D%22%23fff%22/%3E%3Ccircle%20cx%3D%22212%22%20cy%3D%22169%22%20r%3D%222.5%22%20fill%3D%22%231a1a1a%22/%3E%0A%20%20%3Cellipse%20cx%3D%22228%22%20cy%3D%22168%22%20rx%3D%225%22%20ry%3D%226%22%20fill%3D%22%23fff%22/%3E%3Ccircle%20cx%3D%22228%22%20cy%3D%22169%22%20r%3D%222.5%22%20fill%3D%22%231a1a1a%22/%3E%0A%20%20%3Cpath%20d%3D%22M212%20180%20q9%206%2018%200%22%20stroke%3D%22%231a1a1a%22%20stroke-width%3D%222.5%22%20fill%3D%22none%22%20stroke-linecap%3D%22round%22/%3E%0A%20%20%3Cpath%20d%3D%22M238%20210%20l32%20-22%22%20stroke%3D%22%23EF476F%22%20stroke-width%3D%226%22%20stroke-linecap%3D%22round%22/%3E%0A%0A%20%20%3Cg%20stroke%3D%22%23161620%22%20stroke-width%3D%223%22%20stroke-linejoin%3D%22round%22%3E%0A%20%20%20%20%3Cpath%20d%3D%22M262%20208%20q17%20-16%2036%200%20v42%20q-18%208%20-36%200%20z%22%20fill%3D%22%23FFD166%22/%3E%0A%20%20%20%20%3Ccircle%20cx%3D%22280%22%20cy%3D%22180%22%20r%3D%2219%22%20fill%3D%22%23e7b88a%22/%3E%0A%20%20%3C/g%3E%0A%20%20%3Cellipse%20cx%3D%22273%22%20cy%3D%22178%22%20rx%3D%225%22%20ry%3D%226%22%20fill%3D%22%23fff%22/%3E%3Ccircle%20cx%3D%22273%22%20cy%3D%22179%22%20r%3D%222.5%22%20fill%3D%22%231a1a1a%22/%3E%0A%20%20%3Cellipse%20cx%3D%22288%22%20cy%3D%22178%22%20rx%3D%225%22%20ry%3D%226%22%20fill%3D%22%23fff%22/%3E%3Ccircle%20cx%3D%22288%22%20cy%3D%22179%22%20r%3D%222.5%22%20fill%3D%22%231a1a1a%22/%3E%0A%20%20%3Cpath%20d%3D%22M272%20210%20l-28%20-18%22%20stroke%3D%22%23FFD166%22%20stroke-width%3D%226%22%20stroke-linecap%3D%22round%22/%3E%0A%0A%20%20%3Cg%20stroke%3D%22%23161620%22%20stroke-width%3D%223%22%20stroke-linejoin%3D%22round%22%3E%0A%20%20%20%20%3Cpath%20d%3D%22M312%20200%20q17%20-16%2036%200%20v42%20q-18%208%20-36%200%20z%22%20fill%3D%22%236C5CE7%22/%3E%0A%20%20%20%20%3Ccircle%20cx%3D%22330%22%20cy%3D%22172%22%20r%3D%2219%22%20fill%3D%22%23FFD9B3%22/%3E%0A%20%20%3C/g%3E%0A%20%20%3Cellipse%20cx%3D%22323%22%20cy%3D%22170%22%20rx%3D%225%22%20ry%3D%226%22%20fill%3D%22%23fff%22/%3E%3Ccircle%20cx%3D%22323%22%20cy%3D%22171%22%20r%3D%222.5%22%20fill%3D%22%231a1a1a%22/%3E%0A%20%20%3Cellipse%20cx%3D%22338%22%20cy%3D%22170%22%20rx%3D%225%22%20ry%3D%226%22%20fill%3D%22%23fff%22/%3E%3Ccircle%20cx%3D%22338%22%20cy%3D%22171%22%20r%3D%222.5%22%20fill%3D%22%231a1a1a%22/%3E%0A%0A%20%20%3Cg%20fill%3D%22%23EF476F%22%20stroke%3D%22%23161620%22%20stroke-width%3D%222%22%3E%0A%20%20%20%20%3Cellipse%20cx%3D%22255%22%20cy%3D%22128%22%20rx%3D%2228%22%20ry%3D%2217%22/%3E%0A%20%20%20%20%3Cpolygon%20points%3D%22238%2C140%20233%2C154%20250%2C143%22/%3E%0A%20%20%3C/g%3E%0A%20%20%3Ctext%20x%3D%22255%22%20y%3D%22134%22%20font-size%3D%2216%22%20text-anchor%3D%22middle%22%20fill%3D%22%23161620%22%20font-family%3D%22Arial%22%20font-weight%3D%22bold%22%3E%21%21%3C/text%3E%0A%3C/svg%3E%0A",
    opciones: [
      { texto: "Step in, ask them to stop, and stay to talk with the new student.", categoria: "buena", puntos: 5,
        consecuencia: "You calmly approach and ask them to stop. The group disperses and the new student thanks you. Over time you become good friends." },
      { texto: "Don't join in, but tell a teacher afterward about what you saw.", categoria: "aceptable", puntos: 1,
        consecuencia: "You don't take part in the teasing and report it later to a teacher. The situation is addressed, though the new student felt alone in the moment." },
      { texto: "Keep walking so you don't get involved.", categoria: "mala", puntos: -5,
        consecuencia: "You choose not to get involved. The new student feels even more excluded and the teasing continues in the following days." },
    ],
  },
  {
    titulo: "Exam Temptation",
    historia: "You didn't have time to study everything you needed. During the exam, your friend signals that they'll pass you the answers.",
    imagen: "data:image/svg+xml;utf8,%3Csvg%20viewBox%3D%220%200%20400%20300%22%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%3E%0A%20%20%3Cdefs%3E%0A%20%20%20%20%3ClinearGradient%20id%3D%22bg2%22%20x1%3D%220%22%20y1%3D%220%22%20x2%3D%221%22%20y2%3D%221%22%3E%0A%20%20%20%20%20%20%3Cstop%20offset%3D%220%25%22%20stop-color%3D%22%2323232f%22/%3E%0A%20%20%20%20%20%20%3Cstop%20offset%3D%22100%25%22%20stop-color%3D%22%23121218%22/%3E%0A%20%20%20%20%3C/linearGradient%3E%0A%20%20%3C/defs%3E%0A%20%20%3Crect%20width%3D%22400%22%20height%3D%22300%22%20rx%3D%2224%22%20fill%3D%22url%28%23bg2%29%22/%3E%0A%20%20%3Crect%20x%3D%2260%22%20y%3D%22200%22%20width%3D%22120%22%20height%3D%2214%22%20rx%3D%224%22%20fill%3D%22%233a3a4a%22%20stroke%3D%22%23161620%22%20stroke-width%3D%222%22/%3E%0A%20%20%3Crect%20x%3D%22220%22%20y%3D%22200%22%20width%3D%22120%22%20height%3D%2214%22%20rx%3D%224%22%20fill%3D%22%233a3a4a%22%20stroke%3D%22%23161620%22%20stroke-width%3D%222%22/%3E%0A%20%20%3Crect%20x%3D%22100%22%20y%3D%22214%22%20width%3D%2210%22%20height%3D%2250%22%20fill%3D%22%23262633%22/%3E%0A%20%20%3Crect%20x%3D%22150%22%20y%3D%22214%22%20width%3D%2210%22%20height%3D%2250%22%20fill%3D%22%23262633%22/%3E%0A%20%20%3Crect%20x%3D%22260%22%20y%3D%22214%22%20width%3D%2210%22%20height%3D%2250%22%20fill%3D%22%23262633%22/%3E%0A%20%20%3Crect%20x%3D%22310%22%20y%3D%22214%22%20width%3D%2210%22%20height%3D%2250%22%20fill%3D%22%23262633%22/%3E%0A%0A%20%20%3Crect%20x%3D%2290%22%20y%3D%22175%22%20width%3D%2260%22%20height%3D%2230%22%20rx%3D%223%22%20fill%3D%22%23F4F4F9%22%20stroke%3D%22%23161620%22%20stroke-width%3D%222%22/%3E%0A%20%20%3Crect%20x%3D%22250%22%20y%3D%22175%22%20width%3D%2260%22%20height%3D%2230%22%20rx%3D%223%22%20fill%3D%22%23F4F4F9%22%20stroke%3D%22%23161620%22%20stroke-width%3D%222%22/%3E%0A%20%20%3Cg%20stroke%3D%22%239aa0c9%22%20stroke-width%3D%222%22%3E%0A%20%20%20%20%3Cline%20x1%3D%2298%22%20y1%3D%22184%22%20x2%3D%22140%22%20y2%3D%22184%22/%3E%0A%20%20%20%20%3Cline%20x1%3D%2298%22%20y1%3D%22192%22%20x2%3D%22130%22%20y2%3D%22192%22/%3E%0A%20%20%20%20%3Cline%20x1%3D%22258%22%20y1%3D%22184%22%20x2%3D%22300%22%20y2%3D%22184%22/%3E%0A%20%20%20%20%3Cline%20x1%3D%22258%22%20y1%3D%22192%22%20x2%3D%22290%22%20y2%3D%22192%22/%3E%0A%20%20%3C/g%3E%0A%0A%20%20%3Cg%20stroke%3D%22%23161620%22%20stroke-width%3D%223%22%20stroke-linejoin%3D%22round%22%3E%0A%20%20%20%20%3Cpath%20d%3D%22M96%20172%20q24%20-18%2048%200%20v24%22%20fill%3D%22%234ECDC4%22/%3E%0A%20%20%20%20%3Ccircle%20cx%3D%22120%22%20cy%3D%22148%22%20r%3D%2224%22%20fill%3D%22%23FFD9B3%22/%3E%0A%20%20%3C/g%3E%0A%20%20%3Cellipse%20cx%3D%22111%22%20cy%3D%22146%22%20rx%3D%225.5%22%20ry%3D%226.5%22%20fill%3D%22%23fff%22/%3E%3Ccircle%20cx%3D%22111%22%20cy%3D%22147%22%20r%3D%223%22%20fill%3D%22%231a1a1a%22/%3E%0A%20%20%3Cellipse%20cx%3D%22129%22%20cy%3D%22146%22%20rx%3D%225.5%22%20ry%3D%226.5%22%20fill%3D%22%23fff%22/%3E%3Ccircle%20cx%3D%22129%22%20cy%3D%22147%22%20r%3D%223%22%20fill%3D%22%231a1a1a%22/%3E%0A%20%20%3Cpath%20d%3D%22M111%20160%20q9%205%2018%200%22%20stroke%3D%22%237a4a2a%22%20stroke-width%3D%222.5%22%20fill%3D%22none%22%20stroke-linecap%3D%22round%22/%3E%0A%0A%20%20%3Cg%20stroke%3D%22%23161620%22%20stroke-width%3D%223%22%20stroke-linejoin%3D%22round%22%3E%0A%20%20%20%20%3Cpath%20d%3D%22M256%20172%20q24%20-18%2048%200%20v24%22%20fill%3D%22%23FFD166%22/%3E%0A%20%20%20%20%3Ccircle%20cx%3D%22280%22%20cy%3D%22148%22%20r%3D%2224%22%20fill%3D%22%23e7b88a%22/%3E%0A%20%20%3C/g%3E%0A%20%20%3Cellipse%20cx%3D%22271%22%20cy%3D%22146%22%20rx%3D%225.5%22%20ry%3D%226.5%22%20fill%3D%22%23fff%22/%3E%3Ccircle%20cx%3D%22271%22%20cy%3D%22147%22%20r%3D%223%22%20fill%3D%22%231a1a1a%22/%3E%0A%20%20%3Cellipse%20cx%3D%22289%22%20cy%3D%22146%22%20rx%3D%225.5%22%20ry%3D%226.5%22%20fill%3D%22%23fff%22/%3E%3Ccircle%20cx%3D%22289%22%20cy%3D%22147%22%20r%3D%223%22%20fill%3D%22%231a1a1a%22/%3E%0A%0A%20%20%3Cpath%20d%3D%22M144%20148%20q40%20-12%2082%200%22%20stroke%3D%22%23EF476F%22%20stroke-width%3D%223%22%20stroke-dasharray%3D%226%206%22%20fill%3D%22none%22/%3E%0A%20%20%3Cg%20stroke%3D%22%23161620%22%20stroke-width%3D%222%22%3E%0A%20%20%20%20%3Cellipse%20cx%3D%22200%22%20cy%3D%22115%22%20rx%3D%2232%22%20ry%3D%2219%22%20fill%3D%22%23EF476F%22/%3E%0A%20%20%20%20%3Cpolygon%20points%3D%22188%2C132%20178%2C146%20198%2C134%22%20fill%3D%22%23EF476F%22/%3E%0A%20%20%3C/g%3E%0A%20%20%3Ctext%20x%3D%22200%22%20y%3D%22122%22%20font-size%3D%2218%22%20text-anchor%3D%22middle%22%20fill%3D%22%23161620%22%20font-family%3D%22Arial%22%20font-weight%3D%22bold%22%3E%3F%3C/text%3E%0A%3C/svg%3E%0A",
    opciones: [
      { texto: "Turn down the offer and answer with what you actually know.", categoria: "buena", puntos: 5,
        consecuencia: "You choose to be honest with yourself. You get a lower grade than you hoped, but you know exactly what to review." },
      { texto: "Accept help only for one question you truly don't know.", categoria: "aceptable", puntos: 1,
        consecuencia: "You use the help sparingly. You pass the exam, though it doesn't feel entirely fair." },
      { texto: "Copy every answer you can.", categoria: "mala", puntos: -5,
        consecuencia: "You pass the exam, but the teacher notices identical answers with your friend. You both have to retake it." },
    ],
  },
  {
    titulo: "The Free Afternoon",
    historia: "You have an important exam in two days and a whole free afternoon ahead. Your favorite video game just got a new update.",
    imagen: "data:image/svg+xml;utf8,%3Csvg%20viewBox%3D%220%200%20400%20300%22%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%3E%0A%20%20%3Cdefs%3E%0A%20%20%20%20%3ClinearGradient%20id%3D%22bg3%22%20x1%3D%220%22%20y1%3D%220%22%20x2%3D%221%22%20y2%3D%221%22%3E%0A%20%20%20%20%20%20%3Cstop%20offset%3D%220%25%22%20stop-color%3D%22%2323232f%22/%3E%0A%20%20%20%20%20%20%3Cstop%20offset%3D%22100%25%22%20stop-color%3D%22%23121218%22/%3E%0A%20%20%20%20%3C/linearGradient%3E%0A%20%20%3C/defs%3E%0A%20%20%3Crect%20width%3D%22400%22%20height%3D%22300%22%20rx%3D%2224%22%20fill%3D%22url%28%23bg3%29%22/%3E%0A%20%20%3Cpath%20d%3D%22M200%2020%20v260%22%20stroke%3D%22%233a3a4a%22%20stroke-width%3D%223%22%20stroke-dasharray%3D%228%208%22/%3E%0A%0A%20%20%3Cg%20stroke%3D%22%23161620%22%20stroke-width%3D%222.5%22%3E%0A%20%20%20%20%3Crect%20x%3D%2260%22%20y%3D%22190%22%20width%3D%2290%22%20height%3D%2214%22%20rx%3D%223%22%20fill%3D%22%234ECDC4%22/%3E%0A%20%20%20%20%3Crect%20x%3D%2265%22%20y%3D%22176%22%20width%3D%2280%22%20height%3D%2214%22%20rx%3D%223%22%20fill%3D%22%236C5CE7%22/%3E%0A%20%20%20%20%3Crect%20x%3D%2270%22%20y%3D%22162%22%20width%3D%2270%22%20height%3D%2214%22%20rx%3D%223%22%20fill%3D%22%23FFD166%22/%3E%0A%20%20%20%20%3Crect%20x%3D%2295%22%20y%3D%22120%22%20width%3D%2220%22%20height%3D%2242%22%20fill%3D%22%233a3a4a%22/%3E%0A%20%20%20%20%3Ccircle%20cx%3D%22105%22%20cy%3D%22112%22%20r%3D%2214%22%20fill%3D%22%23FFF3D0%22/%3E%0A%20%20%3C/g%3E%0A%0A%20%20%3Cg%20stroke%3D%22%23161620%22%20stroke-width%3D%223%22%3E%0A%20%20%20%20%3Crect%20x%3D%22270%22%20y%3D%22170%22%20width%3D%2290%22%20height%3D%2240%22%20rx%3D%2218%22%20fill%3D%22%23EF476F%22/%3E%0A%20%20%3C/g%3E%0A%20%20%3Ccircle%20cx%3D%22290%22%20cy%3D%22190%22%20r%3D%226%22%20fill%3D%22%231a1a1a%22/%3E%0A%20%20%3Ccircle%20cx%3D%22340%22%20cy%3D%22180%22%20r%3D%226%22%20fill%3D%22%231a1a1a%22/%3E%0A%20%20%3Ccircle%20cx%3D%22350%22%20cy%3D%22190%22%20r%3D%226%22%20fill%3D%22%231a1a1a%22/%3E%0A%20%20%3Ccircle%20cx%3D%22340%22%20cy%3D%22200%22%20r%3D%226%22%20fill%3D%22%231a1a1a%22/%3E%0A%0A%20%20%3Cg%20stroke%3D%22%23161620%22%20stroke-width%3D%223%22%20stroke-linejoin%3D%22round%22%3E%0A%20%20%20%20%3Cpath%20d%3D%22M178%20172%20q22%20-18%2044%200%20v42%20q-22%208%20-44%200%20z%22%20fill%3D%22%23F4F4F9%22/%3E%0A%20%20%20%20%3Ccircle%20cx%3D%22200%22%20cy%3D%22146%22%20r%3D%2224%22%20fill%3D%22%23FFD9B3%22/%3E%0A%20%20%3C/g%3E%0A%20%20%3Cellipse%20cx%3D%22191%22%20cy%3D%22144%22%20rx%3D%225.5%22%20ry%3D%226.5%22%20fill%3D%22%23fff%22/%3E%3Ccircle%20cx%3D%22191%22%20cy%3D%22145%22%20r%3D%223%22%20fill%3D%22%231a1a1a%22/%3E%0A%20%20%3Cellipse%20cx%3D%22209%22%20cy%3D%22144%22%20rx%3D%225.5%22%20ry%3D%226.5%22%20fill%3D%22%23fff%22/%3E%3Ccircle%20cx%3D%22209%22%20cy%3D%22145%22%20r%3D%223%22%20fill%3D%22%231a1a1a%22/%3E%0A%20%20%3Cpath%20d%3D%22M191%20158%20q9%20-4%2018%200%22%20stroke%3D%22%237a4a2a%22%20stroke-width%3D%222.5%22%20fill%3D%22none%22%20stroke-linecap%3D%22round%22/%3E%0A%20%20%3Cpath%20d%3D%22M170%20250%20q30%20-20%2060%200%22%20stroke%3D%22%239aa0c9%22%20stroke-width%3D%223%22%20fill%3D%22none%22%20stroke-dasharray%3D%224%204%22/%3E%0A%3C/svg%3E%0A",
    opciones: [
      { texto: "Plan your time: study first, then play without guilt.", categoria: "buena", puntos: 5,
        consecuencia: "You split your afternoon into blocks. You review the key topics and then enjoy your game, knowing you already did what mattered." },
      { texto: "Play for a while first and leave studying for the night.", categoria: "aceptable", puntos: 1,
        consecuencia: "You end up studying tired and with less focus than you would have had earlier." },
      { texto: "Play all afternoon and leave everything for the last minute.", categoria: "mala", puntos: -5,
        consecuencia: "You arrive at the exam having barely reviewed anything, and the result doesn't reflect what you actually know." },
    ],
  },
  {
    titulo: "The Find on the Street",
    historia: "Walking home, you find a wallet on the sidewalk with money and identification documents inside.",
    imagen: "data:image/svg+xml;utf8,%3Csvg%20viewBox%3D%220%200%20400%20300%22%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%3E%0A%20%20%3Cdefs%3E%0A%20%20%20%20%3ClinearGradient%20id%3D%22bg4%22%20x1%3D%220%22%20y1%3D%220%22%20x2%3D%221%22%20y2%3D%221%22%3E%0A%20%20%20%20%20%20%3Cstop%20offset%3D%220%25%22%20stop-color%3D%22%2323232f%22/%3E%0A%20%20%20%20%20%20%3Cstop%20offset%3D%22100%25%22%20stop-color%3D%22%23121218%22/%3E%0A%20%20%20%20%3C/linearGradient%3E%0A%20%20%3C/defs%3E%0A%20%20%3Crect%20width%3D%22400%22%20height%3D%22300%22%20rx%3D%2224%22%20fill%3D%22url%28%23bg4%29%22/%3E%0A%20%20%3Crect%20x%3D%220%22%20y%3D%22220%22%20width%3D%22400%22%20height%3D%2280%22%20fill%3D%22%23262633%22/%3E%0A%20%20%3Cline%20x1%3D%220%22%20y1%3D%22240%22%20x2%3D%22400%22%20y2%3D%22240%22%20stroke%3D%22%233a3a4a%22%20stroke-width%3D%223%22%20stroke-dasharray%3D%2210%2010%22/%3E%0A%0A%20%20%3Cg%20stroke%3D%22%23161620%22%20stroke-width%3D%223%22%3E%0A%20%20%20%20%3Crect%20x%3D%22160%22%20y%3D%22185%22%20width%3D%2290%22%20height%3D%2260%22%20rx%3D%228%22%20fill%3D%22%236C5CE7%22/%3E%0A%20%20%20%20%3Crect%20x%3D%22160%22%20y%3D%22185%22%20width%3D%2245%22%20height%3D%2260%22%20rx%3D%228%22%20fill%3D%22%235847c7%22/%3E%0A%20%20%3C/g%3E%0A%20%20%3Cline%20x1%3D%22205%22%20y1%3D%22185%22%20x2%3D%22205%22%20y2%3D%22245%22%20stroke%3D%22%231a1a1a%22%20stroke-width%3D%222%22/%3E%0A%0A%20%20%3Ccircle%20cx%3D%22130%22%20cy%3D%22235%22%20r%3D%2212%22%20fill%3D%22%23FFD166%22%20stroke%3D%22%23161620%22%20stroke-width%3D%222%22/%3E%0A%20%20%3Ccircle%20cx%3D%22110%22%20cy%3D%22250%22%20r%3D%2210%22%20fill%3D%22%23FFD166%22%20stroke%3D%22%23161620%22%20stroke-width%3D%222%22/%3E%0A%20%20%3Crect%20x%3D%22255%22%20y%3D%22215%22%20width%3D%2240%22%20height%3D%2220%22%20rx%3D%223%22%20fill%3D%22%234ECDC4%22%20stroke%3D%22%23161620%22%20stroke-width%3D%222%22/%3E%0A%20%20%3Crect%20x%3D%22270%22%20y%3D%22230%22%20width%3D%2240%22%20height%3D%2220%22%20rx%3D%223%22%20fill%3D%22%234ECDC4%22%20stroke%3D%22%23161620%22%20stroke-width%3D%222%22/%3E%0A%0A%20%20%3Cg%20stroke%3D%22%23161620%22%20stroke-width%3D%223%22%20stroke-linejoin%3D%22round%22%3E%0A%20%20%20%20%3Cpath%20d%3D%22M310%20172%20q22%20-18%2044%200%20v42%20q-22%208%20-44%200%20z%22%20fill%3D%22%23EF476F%22/%3E%0A%20%20%20%20%3Ccircle%20cx%3D%22332%22%20cy%3D%22146%22%20r%3D%2224%22%20fill%3D%22%23FFD9B3%22/%3E%0A%20%20%3C/g%3E%0A%20%20%3Cellipse%20cx%3D%22323%22%20cy%3D%22144%22%20rx%3D%225.5%22%20ry%3D%226.5%22%20fill%3D%22%23fff%22/%3E%3Ccircle%20cx%3D%22323%22%20cy%3D%22145%22%20r%3D%223%22%20fill%3D%22%231a1a1a%22/%3E%0A%20%20%3Cellipse%20cx%3D%22341%22%20cy%3D%22144%22%20rx%3D%225.5%22%20ry%3D%226.5%22%20fill%3D%22%23fff%22/%3E%3Ccircle%20cx%3D%22341%22%20cy%3D%22145%22%20r%3D%223%22%20fill%3D%22%231a1a1a%22/%3E%0A%20%20%3Cellipse%20cx%3D%22332%22%20cy%3D%22159%22%20rx%3D%225%22%20ry%3D%224%22%20fill%3D%22%231a1a1a%22/%3E%0A%3C/svg%3E%0A",
    opciones: [
      { texto: "Look for a contact in the documents and return it directly.", categoria: "buena", puntos: 5,
        consecuencia: "You find a phone number and contact the owner. They are extremely grateful for your honesty." },
      { texto: "Hand it to a nearby responsible adult to pass it along.", categoria: "aceptable", puntos: 1,
        consecuencia: "You hand the wallet to someone trustworthy. It will likely reach its owner, though you never confirm it yourself." },
      { texto: "Keep the money and throw away the rest.", categoria: "mala", puntos: -5,
        consecuencia: "You keep the money, but the guilt stays with you for days. The owner loses important documents." },
    ],
  },
  {
    titulo: "The Classroom Accident",
    historia: "You see a classmate accidentally break a vase in the classroom while no one else notices.",
    imagen: "data:image/svg+xml;utf8,%3Csvg%20viewBox%3D%220%200%20400%20300%22%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%3E%0A%20%20%3Cdefs%3E%0A%20%20%20%20%3ClinearGradient%20id%3D%22bg5%22%20x1%3D%220%22%20y1%3D%220%22%20x2%3D%221%22%20y2%3D%221%22%3E%0A%20%20%20%20%20%20%3Cstop%20offset%3D%220%25%22%20stop-color%3D%22%2323232f%22/%3E%0A%20%20%20%20%20%20%3Cstop%20offset%3D%22100%25%22%20stop-color%3D%22%23121218%22/%3E%0A%20%20%20%20%3C/linearGradient%3E%0A%20%20%3C/defs%3E%0A%20%20%3Crect%20width%3D%22400%22%20height%3D%22300%22%20rx%3D%2224%22%20fill%3D%22url%28%23bg5%29%22/%3E%0A%20%20%3Crect%20x%3D%2240%22%20y%3D%2240%22%20width%3D%22320%22%20height%3D%2280%22%20rx%3D%226%22%20fill%3D%22%231f6b5c%22%20stroke%3D%22%23161620%22%20stroke-width%3D%223%22/%3E%0A%20%20%3Cline%20x1%3D%2260%22%20y1%3D%2260%22%20x2%3D%22180%22%20y2%3D%2260%22%20stroke%3D%22%23F4F4F9%22%20stroke-width%3D%223%22%20opacity%3D%220.6%22/%3E%0A%20%20%3Cline%20x1%3D%2260%22%20y1%3D%2280%22%20x2%3D%22150%22%20y2%3D%2280%22%20stroke%3D%22%23F4F4F9%22%20stroke-width%3D%223%22%20opacity%3D%220.6%22/%3E%0A%20%20%3Crect%20x%3D%220%22%20y%3D%22230%22%20width%3D%22400%22%20height%3D%2270%22%20fill%3D%22%23262633%22/%3E%0A%0A%20%20%3Cg%20fill%3D%22%23EF476F%22%20stroke%3D%22%23161620%22%20stroke-width%3D%222%22%3E%0A%20%20%20%20%3Cpolygon%20points%3D%22160%2C230%20190%2C230%20180%2C255%20165%2C250%22/%3E%0A%20%20%20%20%3Cpolygon%20points%3D%22195%2C232%20220%2C235%20210%2C258%20198%2C255%22/%3E%0A%20%20%20%20%3Ccircle%20cx%3D%22150%22%20cy%3D%22248%22%20r%3D%226%22/%3E%0A%20%20%20%20%3Ccircle%20cx%3D%22230%22%20cy%3D%22250%22%20r%3D%228%22/%3E%0A%20%20%3C/g%3E%0A%0A%20%20%3Cg%20stroke%3D%22%23161620%22%20stroke-width%3D%223%22%20stroke-linejoin%3D%22round%22%3E%0A%20%20%20%20%3Cpath%20d%3D%22M270%20197%20q22%20-18%2044%200%20v42%20q-22%208%20-44%200%20z%22%20fill%3D%22%23FFD166%22/%3E%0A%20%20%20%20%3Ccircle%20cx%3D%22292%22%20cy%3D%22171%22%20r%3D%2224%22%20fill%3D%22%23FFD9B3%22/%3E%0A%20%20%3C/g%3E%0A%20%20%3Cellipse%20cx%3D%22283%22%20cy%3D%22168%22%20rx%3D%227%22%20ry%3D%228%22%20fill%3D%22%23fff%22/%3E%3Ccircle%20cx%3D%22283%22%20cy%3D%22169%22%20r%3D%223.5%22%20fill%3D%22%231a1a1a%22/%3E%0A%20%20%3Cellipse%20cx%3D%22301%22%20cy%3D%22168%22%20rx%3D%227%22%20ry%3D%228%22%20fill%3D%22%23fff%22/%3E%3Ccircle%20cx%3D%22301%22%20cy%3D%22169%22%20r%3D%223.5%22%20fill%3D%22%231a1a1a%22/%3E%0A%20%20%3Cellipse%20cx%3D%22292%22%20cy%3D%22184%22%20rx%3D%226%22%20ry%3D%228%22%20fill%3D%22%231a1a1a%22/%3E%0A%3C/svg%3E%0A",
    opciones: [
      { texto: "Encourage them to tell the teacher together right after class.", categoria: "buena", puntos: 5,
        consecuencia: "You both speak honestly with the teacher. They appreciate that you came forward, and there are no major consequences." },
      { texto: "Say nothing yourself, but suggest they tell the teacher alone.", categoria: "aceptable", puntos: 1,
        consecuencia: "Your classmate decides to tell the teacher later, though they hesitate a lot beforehand." },
      { texto: "Suggest staying quiet and blaming someone else if asked.", categoria: "mala", puntos: -5,
        consecuencia: "The lie is discovered days later. The teacher's trust in both of you is affected." },
    ],
  },
  {
    titulo: "A Hurtful Message",
    historia: "You receive an offensive message from an unknown account on social media, mocking your appearance.",
    imagen: "data:image/svg+xml;utf8,%3Csvg%20viewBox%3D%220%200%20400%20300%22%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%3E%0A%20%20%3Cdefs%3E%0A%20%20%20%20%3ClinearGradient%20id%3D%22bg6%22%20x1%3D%220%22%20y1%3D%220%22%20x2%3D%221%22%20y2%3D%221%22%3E%0A%20%20%20%20%20%20%3Cstop%20offset%3D%220%25%22%20stop-color%3D%22%2323232f%22/%3E%0A%20%20%20%20%20%20%3Cstop%20offset%3D%22100%25%22%20stop-color%3D%22%23121218%22/%3E%0A%20%20%20%20%3C/linearGradient%3E%0A%20%20%3C/defs%3E%0A%20%20%3Crect%20width%3D%22400%22%20height%3D%22300%22%20rx%3D%2224%22%20fill%3D%22url%28%23bg6%29%22/%3E%0A%20%20%3Crect%20x%3D%22160%22%20y%3D%2290%22%20width%3D%2290%22%20height%3D%22150%22%20rx%3D%2216%22%20fill%3D%22%230f0f14%22%20stroke%3D%22%23161620%22%20stroke-width%3D%223%22/%3E%0A%20%20%3Crect%20x%3D%22170%22%20y%3D%22105%22%20width%3D%2270%22%20height%3D%22120%22%20rx%3D%224%22%20fill%3D%22%23F4F4F9%22/%3E%0A%20%20%3Crect%20x%3D%22178%22%20y%3D%22115%22%20width%3D%2254%22%20height%3D%2224%22%20rx%3D%2210%22%20fill%3D%22%23EF476F%22%20stroke%3D%22%23161620%22%20stroke-width%3D%222%22/%3E%0A%20%20%3Ctext%20x%3D%22205%22%20y%3D%22131%22%20font-size%3D%2212%22%20text-anchor%3D%22middle%22%20fill%3D%22%23F4F4F9%22%20font-family%3D%22Arial%22%3E%3A%28%3C/text%3E%0A%20%20%3Crect%20x%3D%22178%22%20y%3D%22145%22%20width%3D%2240%22%20height%3D%2216%22%20rx%3D%228%22%20fill%3D%22%236C5CE7%22%20stroke%3D%22%23161620%22%20stroke-width%3D%222%22/%3E%0A%20%20%3Ccircle%20cx%3D%22205%22%20cy%3D%22185%22%20r%3D%2218%22%20fill%3D%22%23FFD166%22%20stroke%3D%22%23161620%22%20stroke-width%3D%222%22/%3E%0A%20%20%3Ctext%20x%3D%22205%22%20y%3D%22192%22%20font-size%3D%2220%22%20text-anchor%3D%22middle%22%20fill%3D%22%231a1a1a%22%20font-family%3D%22Arial%22%20font-weight%3D%22bold%22%3E%21%3C/text%3E%0A%0A%20%20%3Cg%20stroke%3D%22%23161620%22%20stroke-width%3D%223%22%20stroke-linejoin%3D%22round%22%3E%0A%20%20%20%20%3Cpath%20d%3D%22M65%20222%20q22%20-18%2044%200%20v42%20q-22%208%20-44%200%20z%22%20fill%3D%22%234ECDC4%22/%3E%0A%20%20%20%20%3Ccircle%20cx%3D%2287%22%20cy%3D%22196%22%20r%3D%2224%22%20fill%3D%22%23FFD9B3%22/%3E%0A%20%20%3C/g%3E%0A%20%20%3Cpath%20d%3D%22M78%20191%20q9%205%2018%200%22%20stroke%3D%22%231a1a1a%22%20stroke-width%3D%222.5%22%20fill%3D%22none%22%20stroke-linecap%3D%22round%22/%3E%0A%20%20%3Cpath%20d%3D%22M96%20191%20q9%205%2018%200%22%20stroke%3D%22%231a1a1a%22%20stroke-width%3D%222.5%22%20fill%3D%22none%22%20stroke-linecap%3D%22round%22/%3E%0A%20%20%3Cpath%20d%3D%22M78%20209%20q9%20-6%2018%200%22%20stroke%3D%22%237a4a2a%22%20stroke-width%3D%223%22%20fill%3D%22none%22%20stroke-linecap%3D%22round%22/%3E%0A%3C/svg%3E%0A",
    opciones: [
      { texto: "Block the account, save evidence, and tell a trusted adult.", categoria: "buena", puntos: 5,
        consecuencia: "You act calmly and safely. You save the proof, block the account, and get support to handle the situation." },
      { texto: "Reply asking them to stop, without insulting back.", categoria: "aceptable", puntos: 1,
        consecuencia: "The messages stop for a while, but the person starts bothering you again weeks later from another account." },
      { texto: "Reply with more insults.", categoria: "mala", puntos: -5,
        consecuencia: "The argument escalates quickly and you end up feeling worse than before." },
    ],
  },
  {
    titulo: "Your Friends' Plan",
    historia: "Your friends are planning to skip the last class to go to the mall and invite you to join them.",
    imagen: "data:image/svg+xml;utf8,%3Csvg%20viewBox%3D%220%200%20400%20300%22%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%3E%0A%20%20%3Cdefs%3E%0A%20%20%20%20%3ClinearGradient%20id%3D%22bg7%22%20x1%3D%220%22%20y1%3D%220%22%20x2%3D%221%22%20y2%3D%221%22%3E%0A%20%20%20%20%20%20%3Cstop%20offset%3D%220%25%22%20stop-color%3D%22%2323232f%22/%3E%0A%20%20%20%20%20%20%3Cstop%20offset%3D%22100%25%22%20stop-color%3D%22%23121218%22/%3E%0A%20%20%20%20%3C/linearGradient%3E%0A%20%20%3C/defs%3E%0A%20%20%3Crect%20width%3D%22400%22%20height%3D%22300%22%20rx%3D%2224%22%20fill%3D%22url%28%23bg7%29%22/%3E%0A%20%20%3Crect%20x%3D%2240%22%20y%3D%2260%22%20width%3D%22140%22%20height%3D%22110%22%20fill%3D%22%233a3a4a%22%20stroke%3D%22%23161620%22%20stroke-width%3D%223%22/%3E%0A%20%20%3Cpolygon%20points%3D%2240%2C60%20110%2C20%20180%2C60%22%20fill%3D%22%23262633%22%20stroke%3D%22%23161620%22%20stroke-width%3D%223%22/%3E%0A%20%20%3Crect%20x%3D%2270%22%20y%3D%2290%22%20width%3D%2224%22%20height%3D%2224%22%20fill%3D%22%23FFD166%22/%3E%0A%20%20%3Crect%20x%3D%22126%22%20y%3D%2290%22%20width%3D%2224%22%20height%3D%2224%22%20fill%3D%22%23FFD166%22/%3E%0A%20%20%3Crect%20x%3D%2298%22%20y%3D%22130%22%20width%3D%2224%22%20height%3D%2240%22%20fill%3D%22%23121218%22/%3E%0A%20%20%3Crect%20x%3D%220%22%20y%3D%22200%22%20width%3D%22400%22%20height%3D%228%22%20fill%3D%22%23262633%22/%3E%0A%0A%20%20%3Cg%20stroke%3D%22%23161620%22%20stroke-width%3D%223%22%20stroke-linejoin%3D%22round%22%3E%0A%20%20%20%20%3Cpath%20d%3D%22M223%20200%20q17%20-16%2034%200%20v40%20q-17%208%20-34%200%20z%22%20fill%3D%22%23EF476F%22/%3E%0A%20%20%20%20%3Ccircle%20cx%3D%22240%22%20cy%3D%22176%22%20r%3D%2220%22%20fill%3D%22%23FFD9B3%22/%3E%0A%20%20%3C/g%3E%0A%20%20%3Cellipse%20cx%3D%22233%22%20cy%3D%22174%22%20rx%3D%225%22%20ry%3D%226%22%20fill%3D%22%23fff%22/%3E%3Ccircle%20cx%3D%22233%22%20cy%3D%22175%22%20r%3D%222.5%22%20fill%3D%22%231a1a1a%22/%3E%0A%20%20%3Cellipse%20cx%3D%22248%22%20cy%3D%22174%22%20rx%3D%225%22%20ry%3D%226%22%20fill%3D%22%23fff%22/%3E%3Ccircle%20cx%3D%22248%22%20cy%3D%22175%22%20r%3D%222.5%22%20fill%3D%22%231a1a1a%22/%3E%0A%0A%20%20%3Cg%20stroke%3D%22%23161620%22%20stroke-width%3D%223%22%20stroke-linejoin%3D%22round%22%3E%0A%20%20%20%20%3Cpath%20d%3D%22M263%20205%20q17%20-16%2034%200%20v40%20q-17%208%20-34%200%20z%22%20fill%3D%22%23FFD166%22/%3E%0A%20%20%20%20%3Ccircle%20cx%3D%22280%22%20cy%3D%22181%22%20r%3D%2220%22%20fill%3D%22%23e7b88a%22/%3E%0A%20%20%3C/g%3E%0A%20%20%3Cellipse%20cx%3D%22273%22%20cy%3D%22179%22%20rx%3D%225%22%20ry%3D%226%22%20fill%3D%22%23fff%22/%3E%3Ccircle%20cx%3D%22273%22%20cy%3D%22180%22%20r%3D%222.5%22%20fill%3D%22%231a1a1a%22/%3E%0A%20%20%3Cellipse%20cx%3D%22288%22%20cy%3D%22179%22%20rx%3D%225%22%20ry%3D%226%22%20fill%3D%22%23fff%22/%3E%3Ccircle%20cx%3D%22288%22%20cy%3D%22180%22%20r%3D%222.5%22%20fill%3D%22%231a1a1a%22/%3E%0A%0A%20%20%3Cg%20stroke%3D%22%23161620%22%20stroke-width%3D%223%22%20stroke-linejoin%3D%22round%22%3E%0A%20%20%20%20%3Cpath%20d%3D%22M303%20200%20q17%20-16%2034%200%20v40%20q-17%208%20-34%200%20z%22%20fill%3D%22%236C5CE7%22/%3E%0A%20%20%20%20%3Ccircle%20cx%3D%22320%22%20cy%3D%22176%22%20r%3D%2220%22%20fill%3D%22%23FFD9B3%22/%3E%0A%20%20%3C/g%3E%0A%20%20%3Cellipse%20cx%3D%22313%22%20cy%3D%22174%22%20rx%3D%225%22%20ry%3D%226%22%20fill%3D%22%23fff%22/%3E%3Ccircle%20cx%3D%22313%22%20cy%3D%22175%22%20r%3D%222.5%22%20fill%3D%22%231a1a1a%22/%3E%0A%20%20%3Cellipse%20cx%3D%22328%22%20cy%3D%22174%22%20rx%3D%225%22%20ry%3D%226%22%20fill%3D%22%23fff%22/%3E%3Ccircle%20cx%3D%22328%22%20cy%3D%22175%22%20r%3D%222.5%22%20fill%3D%22%231a1a1a%22/%3E%0A%0A%20%20%3Cpath%20d%3D%22M300%20240%20l50%200%20l-12%20-10%20M350%20240%20l-12%2010%22%20stroke%3D%22%234ECDC4%22%20stroke-width%3D%224%22%20fill%3D%22none%22%20stroke-linecap%3D%22round%22%20stroke-linejoin%3D%22round%22/%3E%0A%3C/svg%3E%0A",
    opciones: [
      { texto: "Say no and stay in class.", categoria: "buena", puntos: 5,
        consecuencia: "You stay in class, don't miss important content, and avoid a possible penalty." },
      { texto: "Go for a short while and come back before anyone notices.", categoria: "aceptable", puntos: 1,
        consecuencia: "You make it back on time, but spend the whole time worried about being caught." },
      { texto: "Leave with them for the whole afternoon.", categoria: "mala", puntos: -5,
        consecuencia: "You miss class, your parents get called in, and you lose important content." },
    ],
  },
  {
    titulo: "This Week's Allowance",
    historia: "Your parents give you money to cover your snacks for the entire school week.",
    imagen: "data:image/svg+xml;utf8,%3Csvg%20viewBox%3D%220%200%20400%20300%22%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%3E%0A%20%20%3Cdefs%3E%0A%20%20%20%20%3ClinearGradient%20id%3D%22bg8%22%20x1%3D%220%22%20y1%3D%220%22%20x2%3D%221%22%20y2%3D%221%22%3E%0A%20%20%20%20%20%20%3Cstop%20offset%3D%220%25%22%20stop-color%3D%22%2323232f%22/%3E%0A%20%20%20%20%20%20%3Cstop%20offset%3D%22100%25%22%20stop-color%3D%22%23121218%22/%3E%0A%20%20%20%20%3C/linearGradient%3E%0A%20%20%3C/defs%3E%0A%20%20%3Crect%20width%3D%22400%22%20height%3D%22300%22%20rx%3D%2224%22%20fill%3D%22url%28%23bg8%29%22/%3E%0A%0A%20%20%3Cellipse%20cx%3D%22140%22%20cy%3D%22200%22%20rx%3D%2255%22%20ry%3D%2240%22%20fill%3D%22%23FFD166%22%20stroke%3D%22%23161620%22%20stroke-width%3D%223%22/%3E%0A%20%20%3Ccircle%20cx%3D%22185%22%20cy%3D%22185%22%20r%3D%228%22%20fill%3D%22%23FFD166%22%20stroke%3D%22%23161620%22%20stroke-width%3D%222%22/%3E%0A%20%20%3Crect%20x%3D%22130%22%20y%3D%22165%22%20width%3D%2220%22%20height%3D%228%22%20rx%3D%224%22%20fill%3D%22%231a1a1a%22/%3E%0A%20%20%3Ccircle%20cx%3D%22120%22%20cy%3D%22205%22%20r%3D%224%22%20fill%3D%22%231a1a1a%22/%3E%0A%20%20%3Cellipse%20cx%3D%22155%22%20cy%3D%22192%22%20rx%3D%224%22%20ry%3D%225%22%20fill%3D%22%231a1a1a%22/%3E%0A%0A%20%20%3Ccircle%20cx%3D%22130%22%20cy%3D%22130%22%20r%3D%2210%22%20fill%3D%22%234ECDC4%22%20stroke%3D%22%23161620%22%20stroke-width%3D%222%22/%3E%0A%20%20%3Ccircle%20cx%3D%22155%22%20cy%3D%22110%22%20r%3D%2210%22%20fill%3D%22%234ECDC4%22%20stroke%3D%22%23161620%22%20stroke-width%3D%222%22/%3E%0A%20%20%3Ccircle%20cx%3D%22115%22%20cy%3D%22105%22%20r%3D%228%22%20fill%3D%22%234ECDC4%22%20stroke%3D%22%23161620%22%20stroke-width%3D%222%22/%3E%0A%0A%20%20%3Cpath%20d%3D%22M270%20160%20h60%20l-8%2070%20h-44%20z%22%20fill%3D%22%23EF476F%22%20stroke%3D%22%23161620%22%20stroke-width%3D%223%22/%3E%0A%20%20%3Crect%20x%3D%22285%22%20y%3D%22145%22%20width%3D%2230%22%20height%3D%2220%22%20rx%3D%224%22%20fill%3D%22%23EF476F%22%20stroke%3D%22%23161620%22%20stroke-width%3D%222%22/%3E%0A%20%20%3Ccircle%20cx%3D%22300%22%20cy%3D%22190%22%20r%3D%2210%22%20fill%3D%22%23F4F4F9%22%20opacity%3D%220.5%22/%3E%0A%3C/svg%3E%0A",
    opciones: [
      { texto: "Plan a daily budget before spending anything.", categoria: "buena", puntos: 5,
        consecuencia: "You split the money evenly across the days. It's more than enough and you even have a little left over." },
      { texto: "Spend a bit more the first days and adjust later.", categoria: "aceptable", puntos: 1,
        consecuencia: "You enjoy more at the start of the week, but have to cut back on snacks the last few days." },
      { texto: "Spend almost all of it on candy the first day.", categoria: "mala", puntos: -5,
        consecuencia: "You run out of money for the rest of the week and end up borrowing from a friend." },
    ],
  },
  {
    titulo: "An Unexpected Request",
    historia: "You already had plans with your friends for the afternoon, but an older family member asks for your help with something important right then.",
    imagen: "data:image/svg+xml;utf8,%3Csvg%20viewBox%3D%220%200%20400%20300%22%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%3E%0A%20%20%3Cdefs%3E%0A%20%20%20%20%3ClinearGradient%20id%3D%22bg9%22%20x1%3D%220%22%20y1%3D%220%22%20x2%3D%221%22%20y2%3D%221%22%3E%0A%20%20%20%20%20%20%3Cstop%20offset%3D%220%25%22%20stop-color%3D%22%2323232f%22/%3E%0A%20%20%20%20%20%20%3Cstop%20offset%3D%22100%25%22%20stop-color%3D%22%23121218%22/%3E%0A%20%20%20%20%3C/linearGradient%3E%0A%20%20%3C/defs%3E%0A%20%20%3Crect%20width%3D%22400%22%20height%3D%22300%22%20rx%3D%2224%22%20fill%3D%22url%28%23bg9%29%22/%3E%0A%20%20%3Crect%20x%3D%220%22%20y%3D%22240%22%20width%3D%22400%22%20height%3D%2260%22%20fill%3D%22%23262633%22/%3E%0A%0A%20%20%3Cg%20stroke%3D%22%23161620%22%20stroke-width%3D%223%22%20stroke-linejoin%3D%22round%22%3E%0A%20%20%20%20%3Cpath%20d%3D%22M108%20202%20q22%20-18%2044%200%20v42%20q-22%208%20-44%200%20z%22%20fill%3D%22%236C5CE7%22/%3E%0A%20%20%20%20%3Ccircle%20cx%3D%22130%22%20cy%3D%22176%22%20r%3D%2224%22%20fill%3D%22%23e7b88a%22/%3E%0A%20%20%3C/g%3E%0A%20%20%3Cellipse%20cx%3D%22121%22%20cy%3D%22174%22%20rx%3D%225%22%20ry%3D%226%22%20fill%3D%22%23fff%22/%3E%3Ccircle%20cx%3D%22121%22%20cy%3D%22175%22%20r%3D%222.5%22%20fill%3D%22%231a1a1a%22/%3E%0A%20%20%3Cellipse%20cx%3D%22139%22%20cy%3D%22174%22%20rx%3D%225%22%20ry%3D%226%22%20fill%3D%22%23fff%22/%3E%3Ccircle%20cx%3D%22139%22%20cy%3D%22175%22%20r%3D%222.5%22%20fill%3D%22%231a1a1a%22/%3E%0A%20%20%3Cpath%20d%3D%22M121%20188%20q9%204%2018%200%22%20stroke%3D%22%235c3a1e%22%20stroke-width%3D%222.5%22%20fill%3D%22none%22%20stroke-linecap%3D%22round%22/%3E%0A%20%20%3Crect%20x%3D%2295%22%20y%3D%22235%22%20width%3D%2210%22%20height%3D%2230%22%20fill%3D%22%235a3a1e%22%20stroke%3D%22%23161620%22%20stroke-width%3D%222%22/%3E%0A%20%20%3Cpath%20d%3D%22M150%20215%20q20%205%2030%20-5%22%20stroke%3D%22%23e7b88a%22%20stroke-width%3D%226%22%20fill%3D%22none%22%20stroke-linecap%3D%22round%22/%3E%0A%0A%20%20%3Cg%20stroke%3D%22%23161620%22%20stroke-width%3D%223%22%20stroke-linejoin%3D%22round%22%3E%0A%20%20%20%20%3Cpath%20d%3D%22M268%20192%20q22%20-18%2044%200%20v42%20q-22%208%20-44%200%20z%22%20fill%3D%22%234ECDC4%22/%3E%0A%20%20%20%20%3Ccircle%20cx%3D%22290%22%20cy%3D%22166%22%20r%3D%2224%22%20fill%3D%22%23FFD9B3%22/%3E%0A%20%20%3C/g%3E%0A%20%20%3Cellipse%20cx%3D%22281%22%20cy%3D%22164%22%20rx%3D%225%22%20ry%3D%226%22%20fill%3D%22%23fff%22/%3E%3Ccircle%20cx%3D%22281%22%20cy%3D%22165%22%20r%3D%222.5%22%20fill%3D%22%231a1a1a%22/%3E%0A%20%20%3Cellipse%20cx%3D%22299%22%20cy%3D%22164%22%20rx%3D%225%22%20ry%3D%226%22%20fill%3D%22%23fff%22/%3E%3Ccircle%20cx%3D%22299%22%20cy%3D%22165%22%20r%3D%222.5%22%20fill%3D%22%231a1a1a%22/%3E%0A%20%20%3Crect%20x%3D%22305%22%20y%3D%22195%22%20width%3D%2218%22%20height%3D%2224%22%20rx%3D%224%22%20fill%3D%22%23EF476F%22%20stroke%3D%22%23161620%22%20stroke-width%3D%222%22/%3E%0A%0A%20%20%3Ccircle%20cx%3D%22330%22%20cy%3D%22100%22%20r%3D%2226%22%20fill%3D%22%23FFD166%22%20stroke%3D%22%23161620%22%20stroke-width%3D%223%22/%3E%0A%20%20%3Ccircle%20cx%3D%22330%22%20cy%3D%22100%22%20r%3D%2221%22%20fill%3D%22%231a1a1a%22/%3E%0A%20%20%3Cline%20x1%3D%22330%22%20y1%3D%22100%22%20x2%3D%22330%22%20y2%3D%2286%22%20stroke%3D%22%23FFD166%22%20stroke-width%3D%223%22%20stroke-linecap%3D%22round%22/%3E%0A%20%20%3Cline%20x1%3D%22330%22%20y1%3D%22100%22%20x2%3D%22340%22%20y2%3D%22100%22%20stroke%3D%22%23FFD166%22%20stroke-width%3D%223%22%20stroke-linecap%3D%22round%22/%3E%0A%3C/svg%3E%0A",
    opciones: [
      { texto: "Change your plans and help your family member.", categoria: "buena", puntos: 5,
        consecuencia: "You help your relative, who is deeply grateful. Afterward you reschedule your plans without any real problem." },
      { texto: "Help briefly and then leave to meet your friends.", categoria: "aceptable", puntos: 1,
        consecuencia: "You provide partial help and arrive late to meet your friends. Neither situation feels fully resolved." },
      { texto: "Ignore the request and stick to your original plans.", categoria: "mala", puntos: -5,
        consecuencia: "Your family member has to manage alone. When you learn how hard it was, you feel bad for not being there." },
    ],
  },
  {
    titulo: "Trash in the Schoolyard",
    historia: "You notice trash piling up near your school's gardens. Many students walk by and simply ignore it.",
    imagen: "data:image/svg+xml;utf8,%3Csvg%20viewBox%3D%220%200%20400%20300%22%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%3E%0A%20%20%3Cdefs%3E%0A%20%20%20%20%3ClinearGradient%20id%3D%22bg10%22%20x1%3D%220%22%20y1%3D%220%22%20x2%3D%221%22%20y2%3D%221%22%3E%0A%20%20%20%20%20%20%3Cstop%20offset%3D%220%25%22%20stop-color%3D%22%2323232f%22/%3E%0A%20%20%20%20%20%20%3Cstop%20offset%3D%22100%25%22%20stop-color%3D%22%23121218%22/%3E%0A%20%20%20%20%3C/linearGradient%3E%0A%20%20%3C/defs%3E%0A%20%20%3Crect%20width%3D%22400%22%20height%3D%22300%22%20rx%3D%2224%22%20fill%3D%22url%28%23bg10%29%22/%3E%0A%20%20%3Crect%20x%3D%220%22%20y%3D%22240%22%20width%3D%22400%22%20height%3D%2260%22%20fill%3D%22%23262633%22/%3E%0A%0A%20%20%3Crect%20x%3D%2280%22%20y%3D%22190%22%20width%3D%2216%22%20height%3D%2255%22%20fill%3D%22%235a3a1e%22%20stroke%3D%22%23161620%22%20stroke-width%3D%222%22/%3E%0A%20%20%3Ccircle%20cx%3D%2288%22%20cy%3D%22165%22%20r%3D%2242%22%20fill%3D%22%232fae7a%22%20stroke%3D%22%23161620%22%20stroke-width%3D%223%22/%3E%0A%0A%20%20%3Cg%20fill%3D%22%23EF476F%22%20stroke%3D%22%23161620%22%20stroke-width%3D%222%22%3E%0A%20%20%20%20%3Crect%20x%3D%22150%22%20y%3D%22230%22%20width%3D%2218%22%20height%3D%2212%22%20rx%3D%222%22/%3E%0A%20%20%20%20%3Ccircle%20cx%3D%22190%22%20cy%3D%22235%22%20r%3D%228%22/%3E%0A%20%20%20%20%3Cpolygon%20points%3D%22215%2C225%20230%2C225%20225%2C240%20210%2C238%22/%3E%0A%20%20%3C/g%3E%0A%0A%20%20%3Cg%20stroke%3D%22%23161620%22%20stroke-width%3D%223%22%20stroke-linejoin%3D%22round%22%3E%0A%20%20%20%20%3Cpath%20d%3D%22M278%20197%20q22%20-18%2044%200%20v42%20q-22%208%20-44%200%20z%22%20fill%3D%22%234ECDC4%22/%3E%0A%20%20%20%20%3Ccircle%20cx%3D%22300%22%20cy%3D%22171%22%20r%3D%2224%22%20fill%3D%22%23FFD9B3%22/%3E%0A%20%20%3C/g%3E%0A%20%20%3Cellipse%20cx%3D%22291%22%20cy%3D%22169%22%20rx%3D%225.5%22%20ry%3D%226.5%22%20fill%3D%22%23fff%22/%3E%3Ccircle%20cx%3D%22291%22%20cy%3D%22170%22%20r%3D%223%22%20fill%3D%22%231a1a1a%22/%3E%0A%20%20%3Cellipse%20cx%3D%22309%22%20cy%3D%22169%22%20rx%3D%225.5%22%20ry%3D%226.5%22%20fill%3D%22%23fff%22/%3E%3Ccircle%20cx%3D%22309%22%20cy%3D%22170%22%20r%3D%223%22%20fill%3D%22%231a1a1a%22/%3E%0A%20%20%3Cpath%20d%3D%22M291%20183%20q9%205%2018%200%22%20stroke%3D%22%237a4a2a%22%20stroke-width%3D%222.5%22%20fill%3D%22none%22%20stroke-linecap%3D%22round%22/%3E%0A%20%20%3Crect%20x%3D%22320%22%20y%3D%22205%22%20width%3D%2230%22%20height%3D%2235%22%20rx%3D%224%22%20fill%3D%22%23FFD166%22%20stroke%3D%22%23161620%22%20stroke-width%3D%222%22/%3E%0A%20%20%3Cpath%20d%3D%22M325%20205%20l20%200%22%20stroke%3D%22%231a1a1a%22%20stroke-width%3D%223%22/%3E%0A%3C/svg%3E%0A",
    opciones: [
      { texto: "Organize a clean-up day with classmates and propose recycling points.", categoria: "buena", puntos: 5,
        consecuencia: "You gather a group of students. Together you clean the area, and the school adopts permanent recycling points." },
      { texto: "Pick up as much trash as you can on your own.", categoria: "aceptable", puntos: 1,
        consecuencia: "You improve the area a bit through your own effort, though the underlying problem remains." },
      { texto: "Ignore the problem since it's not directly your responsibility.", categoria: "mala", puntos: -5,
        consecuencia: "The trash keeps piling up and affects the image of the whole school." },
    ],
  },
];

/* ---------------------------------------------------------
   2. NIVELES FINALES por idioma
--------------------------------------------------------- */
const NIVELES = {
  es: [
    { min: 90, max: 100, titulo: "Excelente", mensaje: "Analizas cuidadosamente tus decisiones y asumes las consecuencias de tus actos." },
    { min: 70, max: 89, titulo: "Buen trabajo", mensaje: "Tomas buenas decisiones, aunque aún puedes mejorar analizando algunas situaciones." },
    { min: 50, max: 69, titulo: "Vas por buen camino", mensaje: "Es importante reflexionar más antes de actuar." },
    { min: 0, max: 49, titulo: "Cada decisión construye tu futuro", mensaje: "Analiza mejor las consecuencias antes de elegir." },
  ],
  en: [
    { min: 90, max: 100, titulo: "Excellent", mensaje: "You carefully weigh your decisions and take responsibility for their consequences." },
    { min: 70, max: 89, titulo: "Well done", mensaje: "You make good decisions, though you can still improve by analyzing some situations more." },
    { min: 50, max: 69, titulo: "You're on the right track", mensaje: "It's important to reflect more before acting." },
    { min: 0, max: 49, titulo: "Every decision builds your future", mensaje: "Think through the consequences more carefully before choosing." },
  ],
};

/* ---------------------------------------------------------
   3. TEXTOS DE INTERFAZ por idioma
--------------------------------------------------------- */
const TEXTOS = {
  es: {
    menuEyebrow: "Un juego de decisiones para la vida real",
    menuSubtitulo: "Decisiones que construyen tu camino",
    menuJugar: "Jugar",
    menuOpciones: "Opciones",
    menuSalir: "Salir",
    opcionesTitulo: "Opciones",
    opcionesIdioma: "Idioma",
    opcionesIdiomaEs: "Español",
    opcionesIdiomaEn: "Inglés",
    opcionesColor: "Color de interfaz",
    opcionesColorBordo: "Negro y Bordó",
    opcionesColorAzul: "Azul oscuro y Negro",
    opcionesColorVerde: "Verde oscuro y Negro",
    opcionesVolumen: "Volumen",
    opcionesVolver: "Volver",
    introDescripcion: "Cada día tomas decisiones que parecen pequeñas: cómo tratas a un compañero, qué haces con tu tiempo, cómo reaccionas ante un problema. Ninguna elección es completamente correcta o incorrecta — pero todas dejan una huella en tu camino. Vas a enfrentar 10 situaciones de la vida escolar y cotidiana. Elige con cuidado: tu ruta se construye con cada paso.",
    introComenzar: "Comenzar mi camino",
    puntajeEtiqueta: "Puntaje",
    situacionContador: (n, t) => `Situación ${n} / ${t}`,
    chipBuena: "Buena decisión",
    chipAceptable: "Decisión aceptable",
    chipMala: "Decisión de riesgo",
    continuar: "Continuar",
    puntosGanados: (n) => `${n > 0 ? "+" : ""}${n} ${Math.abs(n) === 1 ? "punto" : "puntos"}`,
    finalEyebrow: "Camino completado",
    finalTitulo: "Tu ruta terminó aquí... por ahora",
    finalPuntosEtiqueta: "Puntos (de -50 a 50)",
    finalRendimiento: "Rendimiento",
    finalVolverJugar: "Volver a jugar",
    finalMenu: "Menú principal",
    salirConfirmarTitulo: "¿Seguro que quieres salir?",
    salirConfirmarTexto: "Se intentará cerrar esta ventana del juego.",
    salirSi: "Sí, salir",
    salirNo: "Cancelar",
    salirMensajeTitulo: "¡Gracias por jugar!",
    salirMensajeManual: "Ya puedes cerrar esta pestaña cuando quieras.",
    salirVolverMenu: "Volver al menú",
  },
  en: {
    menuEyebrow: "A decision-making game for real life",
    menuSubtitulo: "Decisions that build your path",
    menuJugar: "Play",
    menuOpciones: "Options",
    menuSalir: "Exit",
    opcionesTitulo: "Options",
    opcionesIdioma: "Language",
    opcionesIdiomaEs: "Spanish",
    opcionesIdiomaEn: "English",
    opcionesColor: "Interface color",
    opcionesColorBordo: "Black and Maroon",
    opcionesColorAzul: "Dark Blue and Black",
    opcionesColorVerde: "Dark Green and Black",
    opcionesVolumen: "Volume",
    opcionesVolver: "Back",
    introDescripcion: "Every day you make decisions that seem small: how you treat a classmate, what you do with your time, how you react to a problem. No choice is entirely right or wrong — but all of them leave a mark on your path. You'll face 10 situations from school and everyday life. Choose carefully: your path is built one step at a time.",
    introComenzar: "Start my path",
    puntajeEtiqueta: "Score",
    situacionContador: (n, t) => `Situation ${n} / ${t}`,
    chipBuena: "Good decision",
    chipAceptable: "Acceptable decision",
    chipMala: "Risky decision",
    continuar: "Continue",
    puntosGanados: (n) => `${n > 0 ? "+" : ""}${n} ${Math.abs(n) === 1 ? "point" : "points"}`,
    finalEyebrow: "Path completed",
    finalTitulo: "Your path ends here... for now",
    finalPuntosEtiqueta: "Points (-50 to 50)",
    finalRendimiento: "Performance",
    finalVolverJugar: "Play again",
    finalMenu: "Main menu",
    salirConfirmarTitulo: "Are you sure you want to exit?",
    salirConfirmarTexto: "This will try to close the game window.",
    salirSi: "Yes, exit",
    salirNo: "Cancel",
    salirMensajeTitulo: "Thanks for playing!",
    salirMensajeManual: "You can close this tab whenever you like.",
    salirVolverMenu: "Back to menu",
  },
};

/* ---------------------------------------------------------
   4. ESTADO Y CONFIGURACIÓN
--------------------------------------------------------- */
const configuracion = {
  idioma: "es",
  tema: "bordo",
  volumen: 0.6,
};

const estado = {
  indiceActual: 0,
  puntaje: 0,
  historialCategorias: [],
};

function situacionesActuales() {
  return configuracion.idioma === "en" ? SITUACIONES_EN : SITUACIONES_ES;
}

/* ---------------------------------------------------------
   5. REFERENCIAS AL DOM
--------------------------------------------------------- */
const pantallas = {
  menu: document.getElementById("pantalla-menu"),
  opciones: document.getElementById("pantalla-opciones"),
  inicio: document.getElementById("pantalla-inicio"),
  juego: document.getElementById("pantalla-juego"),
  final: document.getElementById("pantalla-final"),
  salir: document.getElementById("pantalla-salir"),
  despedida: document.getElementById("pantalla-despedida"),
};

const btnJugar = document.getElementById("btn-jugar");
const btnOpcionesMenu = document.getElementById("btn-opciones");
const btnSalirMenu = document.getElementById("btn-salir");
const btnVolverOpciones = document.getElementById("btn-volver-opciones");

const selectorIdioma = document.getElementById("selector-idioma");
const selectorTemas = document.getElementById("selector-temas");
const controlVolumen = document.getElementById("control-volumen");
const valorVolumen = document.getElementById("valor-volumen");

const btnComenzar = document.getElementById("btn-comenzar");
const btnContinuar = document.getElementById("btn-continuar");
const btnReiniciar = document.getElementById("btn-reiniciar");
const btnMenuFinal = document.getElementById("btn-menu-final");

const btnSalirSi = document.getElementById("btn-salir-si");
const btnSalirNo = document.getElementById("btn-salir-no");
const btnVolverDespedida = document.getElementById("btn-volver-desde-despedida");

const contadorSituacion = document.getElementById("contador-situacion");
const puntajeActualEl = document.getElementById("puntaje-actual");
const lineaAvance = document.getElementById("linea-avance");
const nodosRuta = document.getElementById("nodos-ruta");

const imgSituacion = document.getElementById("img-situacion");
const tituloSituacion = document.getElementById("titulo-situacion");
const historiaSituacion = document.getElementById("historia-situacion");
const contenedorOpciones = document.getElementById("contenedor-opciones");

const panelConsecuencia = document.getElementById("panel-consecuencia");
const chipResultado = document.getElementById("chip-resultado");
const textoConsecuencia = document.getElementById("texto-consecuencia");
const puntosGanadosEl = document.getElementById("puntos-ganados");

const puntajeFinalEl = document.getElementById("puntaje-final");
const porcentajeFinalEl = document.getElementById("porcentaje-final");
const tituloNivelEl = document.getElementById("titulo-nivel");
const mensajeNivelEl = document.getElementById("mensaje-nivel");
const caminoResumen = document.getElementById("camino-resumen");

/* ---------------------------------------------------------
   6. SONIDO (Web Audio API — sin archivos externos)
--------------------------------------------------------- */
let contextoAudio = null;

function obtenerContextoAudio() {
  if (!contextoAudio) {
    const AudioContextClass = window.AudioContext || window.webkitAudioContext;
    if (AudioContextClass) contextoAudio = new AudioContextClass();
  }
  if (contextoAudio && contextoAudio.state === "suspended") contextoAudio.resume().catch(() => {});
  return contextoAudio;
}

function reproducirTono(frecuencia, duracion = 0.18, tipo = "sine", volumenBase = 0.06) {
  const ctx = obtenerContextoAudio();
  if (!ctx || configuracion.volumen <= 0) return;

  const oscilador = ctx.createOscillator();
  const ganancia = ctx.createGain();
  const volumenFinal = volumenBase * configuracion.volumen;

  oscilador.type = tipo;
  oscilador.frequency.setValueAtTime(frecuencia, ctx.currentTime);
  ganancia.gain.setValueAtTime(volumenFinal, ctx.currentTime);
  ganancia.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + duracion);

  oscilador.connect(ganancia);
  ganancia.connect(ctx.destination);
  oscilador.start();
  oscilador.stop(ctx.currentTime + duracion);
}

function sonidoSeleccion() { reproducirTono(420, 0.12, "sine", 0.05); }
function sonidoClicMenu() { reproducirTono(500, 0.08, "sine", 0.04); }
function sonidoConsecuencia(categoria) {
  if (categoria === "buena") reproducirTono(660, 0.2, "sine", 0.06);
  else if (categoria === "aceptable") reproducirTono(520, 0.2, "triangle", 0.05);
  else reproducirTono(220, 0.25, "sawtooth", 0.04);
}
function sonidoFinal() {
  reproducirTono(523, 0.15, "sine", 0.06);
  setTimeout(() => reproducirTono(659, 0.15, "sine", 0.06), 150);
  setTimeout(() => reproducirTono(784, 0.25, "sine", 0.06), 300);
}

/* ---------------------------------------------------------
   7. NAVEGACIÓN ENTRE PANTALLAS
--------------------------------------------------------- */
function mostrarPantalla(pantalla) {
  Object.values(pantallas).forEach((p) => p.classList.remove("activa"));
  void pantalla.offsetWidth;
  pantalla.classList.add("activa");
}

/* ---------------------------------------------------------
   8. APLICAR IDIOMA / TEMA / VOLUMEN
--------------------------------------------------------- */
function aplicarIdioma() {
  const dic = TEXTOS[configuracion.idioma];

  document.querySelectorAll("[data-i18n]").forEach((el) => {
    const clave = el.getAttribute("data-i18n");
    if (dic[clave] !== undefined && typeof dic[clave] === "string") {
      el.textContent = dic[clave];
    }
  });

  document.documentElement.lang = configuracion.idioma;

  // Actualiza textos dinámicos que no usan data-i18n directamente
  if (pantallas.juego.classList.contains("activa")) {
    contadorSituacion.textContent = dic.situacionContador(estado.indiceActual + 1, situacionesActuales().length);
  }
}

function aplicarTema() {
  document.body.classList.remove("tema-bordo", "tema-azul", "tema-verde");
  document.body.classList.add(`tema-${configuracion.tema}`);

  document.querySelectorAll(".tema-swatch").forEach((btn) => {
    btn.classList.toggle("activo", btn.dataset.tema === configuracion.tema);
  });
}

function aplicarVolumenUI() {
  const porcentaje = Math.round(configuracion.volumen * 100);
  controlVolumen.value = porcentaje;
  valorVolumen.textContent = `${porcentaje}%`;
}

/* ---------------------------------------------------------
   9. LÓGICA DEL JUEGO
--------------------------------------------------------- */
function construirNodosRuta() {
  nodosRuta.innerHTML = "";
  situacionesActuales().forEach((_, i) => {
    const nodo = document.createElement("div");
    nodo.className = "nodo";
    nodo.textContent = i + 1;
    nodo.id = `nodo-${i}`;
    nodosRuta.appendChild(nodo);
  });
}

function actualizarBarraRuta() {
  const total = situacionesActuales().length;
  const progreso = (estado.indiceActual / total) * 100;
  lineaAvance.style.width = `${progreso}%`;

  situacionesActuales().forEach((_, i) => {
    const nodo = document.getElementById(`nodo-${i}`);
    if (!nodo) return;
    nodo.classList.remove("actual", "buena", "aceptable", "mala");
    if (i < estado.historialCategorias.length) {
      nodo.classList.add(estado.historialCategorias[i]);
    } else if (i === estado.indiceActual) {
      nodo.classList.add("actual");
    }
  });
}

// Baraja un arreglo sin modificar el original (algoritmo de Fisher-Yates).
// Se usa para que el orden de las opciones (buena / aceptable / mala)
// cambie cada vez y no sea predecible por su posición.
function barajar(arreglo) {
  const copia = [...arreglo];
  for (let i = copia.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [copia[i], copia[j]] = [copia[j], copia[i]];
  }
  return copia;
}

function renderizarSituacion() {
  const dic = TEXTOS[configuracion.idioma];
  const situacion = situacionesActuales()[estado.indiceActual];

  contadorSituacion.textContent = dic.situacionContador(estado.indiceActual + 1, situacionesActuales().length);
  puntajeActualEl.textContent = estado.puntaje;
  puntajeActualEl.classList.toggle("negativo", estado.puntaje < 0);

  imgSituacion.src = situacion.imagen;
  imgSituacion.alt = situacion.titulo;
  tituloSituacion.textContent = situacion.titulo;
  historiaSituacion.textContent = situacion.historia;

  contenedorOpciones.innerHTML = "";
  const letras = ["A", "B", "C"];

  // Orden aleatorio de las opciones en cada situación, para que la
  // decisión buena/aceptable/mala no siempre caiga en el mismo lugar.
  const opcionesBarajadas = barajar(situacion.opciones);

  // Patrón de filas aleatorio (columna única, o combinaciones en dos
  // columnas) para que la disposición visual también cambie cada vez.
  const patrones = ["patron-1", "patron-2", "patron-3", "patron-4"];
  const patronElegido = patrones[Math.floor(Math.random() * patrones.length)];
  contenedorOpciones.className = `opciones ${patronElegido}`;

  opcionesBarajadas.forEach((opcion, i) => {
    const boton = document.createElement("button");
    boton.className = "opcion";
    boton.innerHTML = `<span class="letra">${letras[i]}</span><span>${opcion.texto}</span>`;
    boton.addEventListener("click", () => elegirOpcion(opcion, boton));
    contenedorOpciones.appendChild(boton);
  });

  actualizarBarraRuta();
}

function elegirOpcion(opcion, botonElegido) {
  sonidoSeleccion();

  document.querySelectorAll(".opcion").forEach((btn) => { btn.disabled = true; });
  botonElegido.style.borderColor = "var(--acento-1)";

  estado.puntaje += opcion.puntos;
  estado.historialCategorias.push(opcion.categoria);

  const dic = TEXTOS[configuracion.idioma];
  const etiquetas = { buena: dic.chipBuena, aceptable: dic.chipAceptable, mala: dic.chipMala };

  chipResultado.textContent = etiquetas[opcion.categoria];
  chipResultado.className = `chip-resultado ${opcion.categoria}`;
  textoConsecuencia.textContent = opcion.consecuencia;
  puntosGanadosEl.textContent = dic.puntosGanados(opcion.puntos);
  puntosGanadosEl.className = `puntos-ganados ${opcion.categoria}`;

  sonidoConsecuencia(opcion.categoria);

  setTimeout(() => { panelConsecuencia.classList.add("mostrar"); }, 250);
}

function continuarJuego() {
  panelConsecuencia.classList.remove("mostrar");
  estado.indiceActual += 1;

  if (estado.indiceActual >= situacionesActuales().length) {
    setTimeout(mostrarPantallaFinal, 200);
  } else {
    setTimeout(renderizarSituacion, 200);
  }
}

function obtenerNivel(puntaje) {
  const lista = NIVELES[configuracion.idioma];
  return lista.find((n) => puntaje >= n.min && puntaje <= n.max) || lista[lista.length - 1];
}

function mostrarPantallaFinal() {
  actualizarBarraRuta();

  const total = situacionesActuales().length;
  const porcentaje = Math.round(((estado.puntaje + total * 5) / (total * 10)) * 100);
  const nivel = obtenerNivel(porcentaje);

  puntajeFinalEl.textContent = estado.puntaje;
  porcentajeFinalEl.textContent = `${porcentaje}%`;
  tituloNivelEl.textContent = nivel.titulo;
  mensajeNivelEl.textContent = nivel.mensaje;

  caminoResumen.innerHTML = "";
  estado.historialCategorias.forEach((categoria) => {
    const punto = document.createElement("span");
    punto.className = `punto ${categoria}`;
    caminoResumen.appendChild(punto);
  });

  sonidoFinal();
  mostrarPantalla(pantallas.final);
}

function reiniciarJuego() {
  estado.indiceActual = 0;
  estado.puntaje = 0;
  estado.historialCategorias = [];

  construirNodosRuta();
  renderizarSituacion();
  mostrarPantalla(pantallas.juego);
}

function irAExplicacion() {
  obtenerContextoAudio();
  sonidoClicMenu();
  mostrarPantalla(pantallas.inicio);
}

function iniciarJuegoDesdeExplicacion() {
  estado.indiceActual = 0;
  estado.puntaje = 0;
  estado.historialCategorias = [];

  construirNodosRuta();
  renderizarSituacion();
  mostrarPantalla(pantallas.juego);
}

function volverAlMenu() {
  mostrarPantalla(pantallas.menu);
}

/* ---------------------------------------------------------
   10. EVENTOS
--------------------------------------------------------- */
btnJugar.addEventListener("click", irAExplicacion);
btnComenzar.addEventListener("click", iniciarJuegoDesdeExplicacion);
btnContinuar.addEventListener("click", continuarJuego);
btnReiniciar.addEventListener("click", reiniciarJuego);
btnMenuFinal.addEventListener("click", volverAlMenu);

/* -- Opciones -- */
btnOpcionesMenu.addEventListener("click", () => {
  sonidoClicMenu();
  mostrarPantalla(pantallas.opciones);
});

btnVolverOpciones.addEventListener("click", () => {
  sonidoClicMenu();
  mostrarPantalla(pantallas.menu);
});

selectorIdioma.addEventListener("click", (e) => {
  const boton = e.target.closest(".chip-selector");
  if (!boton) return;
  configuracion.idioma = boton.dataset.valor;

  selectorIdioma.querySelectorAll(".chip-selector").forEach((b) => {
    b.classList.toggle("activo", b === boton);
  });

  aplicarIdioma();
  sonidoClicMenu();
});

selectorTemas.addEventListener("click", (e) => {
  const boton = e.target.closest(".tema-swatch");
  if (!boton) return;
  configuracion.tema = boton.dataset.tema;
  aplicarTema();
  sonidoClicMenu();
});

controlVolumen.addEventListener("input", () => {
  configuracion.volumen = Number(controlVolumen.value) / 100;
  valorVolumen.textContent = `${controlVolumen.value}%`;
});

controlVolumen.addEventListener("change", () => {
  obtenerContextoAudio();
  sonidoSeleccion();
});

/* -- Salir -- */
btnSalirMenu.addEventListener("click", () => {
  sonidoClicMenu();
  mostrarPantalla(pantallas.salir);
});

btnSalirNo.addEventListener("click", () => {
  sonidoClicMenu();
  mostrarPantalla(pantallas.menu);
});

btnSalirSi.addEventListener("click", () => {
  window.close();
  setTimeout(() => {
    mostrarPantalla(pantallas.despedida);
  }, 300);
});

btnVolverDespedida.addEventListener("click", () => {
  mostrarPantalla(pantallas.menu);
});

/* ---------------------------------------------------------
   11. INICIALIZACIÓN
--------------------------------------------------------- */
document.addEventListener("keydown", (e) => {
  if (e.ctrlKey || e.metaKey || e.altKey) return;
  const k = e.key.toLowerCase();
  if (panelConsecuencia.classList.contains("mostrar")) {
    if (k === "enter" || k === " ") { e.preventDefault(); continuarJuego(); }
    return;
  }
  if (pantallas.juego.classList.contains("activa") || pantallas.juego.classList.contains("visible") || pantallas.juego.offsetParent !== null) {
    const idx = { "1": 0, "2": 1, "3": 2, a: 0, b: 1, c: 2 }[k];
    const botones = document.querySelectorAll(".opcion:not(:disabled)");
    if (idx !== undefined && botones[idx]) botones[idx].click();
  }
});

aplicarTema();
aplicarVolumenUI();
aplicarIdioma();
